package com.seuapp.mrquest.nativo;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Gravity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.os.Build;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Cena 3D nativa: botões "Entrar" e "Entrar em modo VR" da tela inicial. A câmera segue o 6DOF simulado. */
public class CenaActivity extends Activity {
    private GLSurfaceView gl;
    private Pose6Dof pose;
    private TextView hud;
    private CenaRenderer rend;
    private boolean vr, ativa;
    private CamaraFundo cam;
    private Mao mao;
    private MaoOverlay overlay;
    private boolean pinchAnt;
    private float[] suavX, suavY;
    private SurfaceTexture stCam;
    private FrameLayout raiz;
    private JanelaFlutuante janApps, janNav;
    private NavegadorView nav;
    private static final class FixaJ { JanelaFlutuante j; int id; android.graphics.Bitmap[] bm = new android.graphics.Bitmap[2]; int k; }
    private final java.util.ArrayList<FixaJ> fixas = new java.util.ArrayList<FixaJ>();
    private int proxId = 1;
    private final Runnable tickFixas = new Runnable() {
        @Override public void run() {
            if (fixas.isEmpty()) return;
            for (int i = 0; i < fixas.size(); i++) atualizarFixa(fixas.get(i));
            h.postDelayed(this, 150);
        }
    };
    // controle (PS4/Xbox)
    private float ctrlLx, ctrlLy, ctrlRx;
    private boolean ctrlLoop, r2Ant;
    private long ctrlT;
    private View mira;
    private boolean imgTentou;
    private final Runnable tickCtrl = new Runnable() {
        @Override public void run() {
            if (!ativa) { ctrlLoop = false; return; }
            long n = SystemClock.uptimeMillis();
            float dt = Math.min(.1f, (n - ctrlT) / 1000f);
            ctrlT = n;
            if (ctrlRx != 0) pose.giroExtra(ctrlRx * 1.8f * dt);
            if (ctrlLx != 0 || ctrlLy != 0) pose.andarDireto(-ctrlLy * 1.4f * dt, ctrlLx * 1.4f * dt);
            h.postDelayed(this, 16);
        }
    };
    private LinearLayout bar;
    private boolean botoesOcultos;
    private long ocultouEm;

    // resolução: 0 = 100%, 1 = 75%, 2 = 50%
    private static final float[] ESC = {1f, .75f, .5f};
    private int autoIdx = 1, resAplicada = -99, ruim, bom;
    private final Handler h = new Handler();

    private final Runnable atualiza = new Runnable() {
        @Override public void run() {
            ajustarRot();
            CenaRenderer.camEstado = cam.estado;
            aplicarDesempenho();
            hud.setText(String.format(Locale.US, "x %.2f  y %.2f  z %.2f m · giro %d° · %d passos · %.0f fps · res %d%%\n%s",
                    pose.x, pose.y, pose.z, Math.round(Math.toDegrees(pose.yaw)), pose.passos, CenaRenderer.fps, Math.round(ESC[Math.max(0, resAplicada)] * 100), pose.fonte));
            h.postDelayed(this, 250);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Estado.init(this);
        pose = Pose6Dof.get(this);
        vr = getIntent().getBooleanExtra("vr", false);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        raiz = new FrameLayout(this);
        raiz.setBackgroundColor(0xFF0A0C12);

        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        gl.setPreserveEGLContextOnPause(true);
        rend = new CenaRenderer(pose, vr);
        cam = new CamaraFundo(this);
        rend.ouvinte = new CenaRenderer.Ouvinte() {
            @Override public void texturaPronta(SurfaceTexture st) {
                stCam = st;
                runOnUiThread(new Runnable() { @Override public void run() { abrirCamera(); } });
            }
        };
        gl.setRenderer(rend);
        gl.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) revelarBotoes();
                if (e.getAction() == MotionEvent.ACTION_UP) tocar(e.getX() / Math.max(1, v.getWidth()) * 2 - 1, 1 - e.getY() / Math.max(1, v.getHeight()) * 2);
                return true;
            }
        });
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        raiz.addView(gl, new FrameLayout.LayoutParams(-1, -1));
        overlay = new MaoOverlay(this);
        raiz.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        float d = getResources().getDisplayMetrics().density;
        hud = new TextView(this);
        hud.setTypeface(Typeface.MONOSPACE);
        hud.setTextSize(11);
        hud.setTextColor(0xCCDDE6FF);
        hud.setBackgroundColor(0x66000000);
        hud.setPadding((int) (8 * d), (int) (4 * d), (int) (8 * d), (int) (4 * d));
        FrameLayout.LayoutParams lh = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        lh.setMargins((int) (8 * d), (int) (8 * d), 0, 0);
        raiz.addView(hud, lh);

        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.addView(botao("↺ Recentrar", new View.OnClickListener() {
            @Override public void onClick(View v) { pose.recentrar(); }
        }));
        bar.addView(botao("◐ Câmera", new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean on = !Estado.b("cam_on", true);
                Estado.put("cam_on", on);
                if (on) { pedirPermissao(); abrirCamera(); } else fecharCamera();
            }
        }));
        bar.addView(botao("✋ Mão", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Estado.put("mao_on", !Estado.b("mao_on", true));
                fecharCamera();      // reabre já com (ou sem) a saída da detecção
                abrirCamera();
            }
        }));
        bar.addView(botao("▦ Organizar", new View.OnClickListener() {
            @Override public void onClick(View v) { organizar(); }
        }));
        bar.addView(botao("👁 Ocultar", new View.OnClickListener() {
            @Override public void onClick(View v) {
                botoesOcultos = true;
                ocultouEm = SystemClock.uptimeMillis();
                bar.setVisibility(View.GONE);
                Toast.makeText(CenaActivity.this, "Botões ocultos — toque na tela para mostrar", Toast.LENGTH_SHORT).show();
            }
        }));
        bar.addView(botao("✕ Sair", new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        }));
        FrameLayout.LayoutParams lb = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        lb.setMargins(0, (int) (8 * d), (int) (8 * d), 0);
        raiz.addView(bar, lb);

        mira = new TextView(this);
        ((TextView) mira).setText("+");
        ((TextView) mira).setTextColor(0xCCFFFFFF);
        ((TextView) mira).setTextSize(26);
        mira.setVisibility(View.GONE);
        raiz.addView(mira, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        setContentView(raiz);
    }

    /** Toque na tela (no modo VR, o ponto vira o centro da tela = olhar). Ícones do dock: 0 apps, 1 configurações, 2 celular. */
    private void tocar(float nx, float ny) {
        float[] fx = rend.acertoFixa(vr && mao == null ? 0f : nx, vr && mao == null ? 0f : ny);
        if (fx != null && toqueFixa((int) fx[0], fx[1], fx[2])) return;
        int i = rend.acerto(vr && mao == null ? 0f : nx, vr && mao == null ? 0f : ny);
        if (i >= 0) feedback();
        if (i == 1) startActivity(new Intent(this, ConfigActivity.class));
        else if (i == 0) alternarJanelaApps();
        else if (i == 2) alternarJanelaNav();
    }

    // ---------- ocultar botões, sons/vibração, toque da mão nas janelas ----------
    private void revelarBotoes() {
        if (botoesOcultos && SystemClock.uptimeMillis() - ocultouEm > 350) { botoesOcultos = false; bar.setVisibility(View.VISIBLE); }
    }

    /** Configurações > Interface > Sons e vibração: clique do sistema + vibração curta. */
    private void feedback() {
        if (!Estado.b("ui_snd", true)) return;
        try { gl.playSoundEffect(android.view.SoundEffectConstants.CLICK); } catch (Throwable t) { }
        try {
            android.os.Vibrator vb = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vb != null) vb.vibrate(15);
        } catch (Throwable t) { }
    }

    /** Belisco da mão sobre uma janela flutuante vira um toque nela (coordenadas -1..1 → pixels). */
    private boolean toqueJanela(float nx, float ny) {
        int W = raiz.getWidth(), H = raiz.getHeight();
        if (W <= 0 || H <= 0) return false;
        final float x = (nx + 1f) / 2f * W, y = (1f - ny) / 2f * H;
        JanelaFlutuante[] js = {janNav, janApps};
        for (JanelaFlutuante j : js) {
            if (j == null || j.fixada || x < j.getLeft() || x > j.getRight() || y < j.getTop() || y > j.getBottom()) continue;
            long t = SystemClock.uptimeMillis();
            MotionEvent d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
            raiz.dispatchTouchEvent(d);
            d.recycle();
            h.postDelayed(new Runnable() {
                @Override public void run() {
                    long t2 = SystemClock.uptimeMillis();
                    MotionEvent u = MotionEvent.obtain(t2 - 60, t2, MotionEvent.ACTION_UP, x, y, 0);
                    raiz.dispatchTouchEvent(u);
                    u.recycle();
                }
            }, 60);
            feedback();
            return true;
        }
        return false;
    }

    // ---------- imagem de cenário ----------
    private void carregarImagemCeu() {
        if (imgTentou) return;
        imgTentou = true;
        new Thread(new Runnable() {
            @Override public void run() {
                java.io.File f = new java.io.File(getFilesDir(), "cenario_img.jpg");
                android.graphics.Bitmap b = f.exists() ? android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
                if (b != null) rend.definirImagem(b);
            }
        }).start();
    }

    // ---------- organizar janelas ----------
    /** ▦ / □: prende as janelas abertas e as distribui em arco na frente do olhar. */
    private void organizar() {
        if (janApps != null && achar(janApps) == null) alternarFixa(janApps);
        if (janNav != null && achar(janNav) == null) alternarFixa(janNav);
        int n = fixas.size();
        if (n == 0) { Toast.makeText(this, "Abra uma janela (dock) para organizar", Toast.LENGTH_SHORT).show(); return; }
        float passo = (float) Math.toRadians(38), dist = 1.4f;
        for (int i = 0; i < n; i++) {
            float a = pose.yaw + (i - (n - 1) / 2f) * passo;
            rend.moverFixa(fixas.get(i).id, pose.x + (float) Math.sin(a) * dist, pose.y, pose.z - (float) Math.cos(a) * dist, (float) Math.toDegrees(-a));
        }
    }

    // ---------- controle (PS4/Xbox) ----------
    private static float zona(float v) { return Math.abs(v) < .15f ? 0f : v; }

    private void ligarCtrl() {
        mira.setVisibility(View.VISIBLE);
        if (!ctrlLoop) { ctrlLoop = true; ctrlT = SystemClock.uptimeMillis(); h.post(tickCtrl); }
    }

    /** Clique do controle = toque no centro da tela (a mira +). */
    private void clicarMira() { revelarBotoes(); tocar(0f, 0f); }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent e) {
        if (Estado.b("ctrl_on", true) && (e.getSource() & android.view.InputDevice.SOURCE_JOYSTICK) == android.view.InputDevice.SOURCE_JOYSTICK
                && e.getAction() == MotionEvent.ACTION_MOVE) {
            ctrlLx = zona(e.getAxisValue(MotionEvent.AXIS_X));
            ctrlLy = zona(e.getAxisValue(MotionEvent.AXIS_Y));
            ctrlRx = zona(e.getAxisValue(MotionEvent.AXIS_Z));
            boolean p = Math.max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS)) > .6f;
            if (p && !r2Ant) clicarMira();
            r2Ant = p;
            ligarCtrl();
            return true;
        }
        return super.dispatchGenericMotionEvent(e);
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (Estado.b("ctrl_on", true) && e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0
                && (e.getSource() & android.view.InputDevice.SOURCE_GAMEPAD) == android.view.InputDevice.SOURCE_GAMEPAD) {
            boolean usou = true;
            switch (e.getKeyCode()) {
                case KeyEvent.KEYCODE_BUTTON_A:
                case KeyEvent.KEYCODE_BUTTON_R2: clicarMira(); break;                   // ✕ / R2
                case KeyEvent.KEYCODE_BUTTON_Y: pose.recentrar(); break;                // △
                case KeyEvent.KEYCODE_BUTTON_X: organizar(); break;                     // □
                case KeyEvent.KEYCODE_BUTTON_L1: alternarJanelaApps(); break;
                case KeyEvent.KEYCODE_BUTTON_R1: alternarJanelaNav(); break;
                case KeyEvent.KEYCODE_BUTTON_B:                                         // ○
                    if (botoesOcultos) { ocultouEm = 0; revelarBotoes(); } else { botoesOcultos = true; ocultouEm = SystemClock.uptimeMillis(); bar.setVisibility(View.GONE); }
                    break;
                case KeyEvent.KEYCODE_BUTTON_START: startActivity(new Intent(this, ConfigActivity.class)); break;   // Options
                default: usou = false;
            }
            if (usou) { ligarCtrl(); return true; }
        }
        return super.dispatchKeyEvent(e);
    }

    // ---------- janelas fixas no ambiente ----------
    private FixaJ achar(JanelaFlutuante j) {
        for (FixaJ f : fixas) if (f.j == j) return f;
        return null;
    }

    /** 📌: a janela vira uma textura no mundo, a ~1,3 m na direção do olhar, e fica ali enquanto você se move. */
    private void alternarFixa(JanelaFlutuante j) {
        if (j == null) return;
        FixaJ f = achar(j);
        if (f != null) { soltar(f); return; }
        if (j.getWidth() <= 0 || j.getHeight() <= 0) return;
        f = new FixaJ();
        f.j = j;
        f.id = proxId++;
        float hm = 0.75f, wm = hm * j.getWidth() / j.getHeight();
        float yaw = pose.yaw, dist = 1.3f;
        float x = pose.x + (float) Math.sin(yaw) * dist, z = pose.z - (float) Math.cos(yaw) * dist;
        rend.adicionarFixa(f.id, x, pose.y, z, (float) Math.toDegrees(-yaw), wm, hm);
        fixas.add(f);
        j.marcarFixada(true);
        j.setVisibility(View.INVISIBLE);
        atualizarFixa(f);
        h.removeCallbacks(tickFixas);
        h.post(tickFixas);
        Toast.makeText(this, "Janela fixada no ambiente — toque no 📌 dela para soltar", Toast.LENGTH_SHORT).show();
    }

    private void soltar(FixaJ f) {
        rend.removerFixa(f.id);
        fixas.remove(f);
        f.j.marcarFixada(false);
        f.j.setVisibility(View.VISIBLE);
    }

    private void soltarPorJanela(JanelaFlutuante j) {
        FixaJ f = achar(j);
        if (f == null) return;
        rend.removerFixa(f.id);
        fixas.remove(f);
        j.marcarFixada(false);
    }

    /** Desenha a View num Bitmap (até 640 px de largura) e entrega à textura. Dois Bitmaps alternados, para não ler e escrever no mesmo. */
    private void atualizarFixa(FixaJ f) {
        JanelaFlutuante j = f.j;
        int w = j.getWidth(), hh = j.getHeight();
        if (w <= 0 || hh <= 0) return;
        float esc = Math.min(1f, 640f / w);
        int bw = Math.max(1, Math.round(w * esc)), bh = Math.max(1, Math.round(hh * esc));
        f.k ^= 1;
        android.graphics.Bitmap b = f.bm[f.k];
        if (b == null || b.getWidth() != bw || b.getHeight() != bh) {
            b = android.graphics.Bitmap.createBitmap(bw, bh, android.graphics.Bitmap.Config.ARGB_8888);
            f.bm[f.k] = b;
        }
        b.eraseColor(0);
        android.graphics.Canvas c = new android.graphics.Canvas(b);
        c.scale(esc, esc);
        try { j.draw(c); } catch (Throwable t) { return; }
        rend.enviarQuadro(f.id, b, (float) w / hh);
    }

    /** Toque (tela ou belisco) numa janela fixa: u,v de 0 a 1 viram um toque na View, em pixels dela. */
    private boolean toqueFixa(int id, float u, float v) {
        FixaJ alvo = null;
        for (FixaJ f : fixas) if (f.id == id) alvo = f;
        if (alvo == null) return false;
        final JanelaFlutuante j = alvo.j;
        final float x = u * j.getWidth(), y = v * j.getHeight();
        long t = SystemClock.uptimeMillis();
        MotionEvent d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
        j.dispatchTouchEvent(d);
        d.recycle();
        h.postDelayed(new Runnable() {
            @Override public void run() {
                long t2 = SystemClock.uptimeMillis();
                MotionEvent up = MotionEvent.obtain(t2 - 60, t2, MotionEvent.ACTION_UP, x, y, 0);
                j.dispatchTouchEvent(up);
                up.recycle();
            }
        }, 60);
        feedback();
        return true;
    }

    // ---------- janela flutuante de apps ----------
    /** Ícone da esquerda do dock: abre/fecha a janela "Apps" por cima da cena. */
    private void alternarJanelaApps() {
        if (janApps != null) { janApps.fechar(); return; }
        janApps = new JanelaFlutuante(this, "Apps instalados");
        janApps.ouvinte = new JanelaFlutuante.Ouvinte() {
            @Override public void aoFechar(JanelaFlutuante j) { soltarPorJanela(j); if (j == janApps) janApps = null; }
        };
        janApps.aoFixar = new Runnable() { @Override public void run() { alternarFixa(janApps); } };
        janApps.definirConteudo(new AppsGrade(this, 84, new AppsGrade.Ouvinte() {
            @Override public void abrir(String pacote, String nome) { abrirApp(pacote); }
        }));
        janApps.mostrarEm(raiz, 360, 260);
    }

    /** Ícone da direita do dock: abre/fecha a janela do navegador (páginas e apps HTML). */
    private void alternarJanelaNav() {
        if (janNav != null) { janNav.fechar(); return; }
        janNav = new JanelaFlutuante(this, "Navegador");
        janNav.ouvinte = new JanelaFlutuante.Ouvinte() {
            @Override public void aoFechar(JanelaFlutuante j) {
                soltarPorJanela(j);
                if (j == janNav) { janNav = null; if (nav != null) { nav.destruir(); nav = null; } }
            }
        };
        janNav.aoFixar = new Runnable() { @Override public void run() { alternarFixa(janNav); } };
        nav = new NavegadorView(this);
        nav.aoPedirArquivo = new Runnable() {
            @Override public void run() {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(i, 21);
            }
        };
        janNav.definirConteudo(nav);
        janNav.mostrarEm(raiz, 420, 300);
    }

    /** Abre o app. No Android 7+ pede para abrir na área da janela; só vale em aparelhos com modo de janelas livres, senão abre em tela cheia. */
    private void abrirApp(String pacote) {
        Intent in = getPackageManager().getLaunchIntentForPackage(pacote);
        if (in == null) { Toast.makeText(this, "Não foi possível abrir", Toast.LENGTH_SHORT).show(); return; }
        Bundle op = null;
        if (Build.VERSION.SDK_INT >= 24 && janApps != null) {
            try {
                int[] l = new int[2];
                janApps.getLocationOnScreen(l);
                android.app.ActivityOptions o = android.app.ActivityOptions.makeBasic();
                o.setLaunchBounds(new android.graphics.Rect(l[0], l[1], l[0] + janApps.getWidth(), l[1] + janApps.getHeight()));
                op = o.toBundle();
            } catch (Throwable t) { op = null; }
        }
        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(in, op); } catch (Throwable t) { startActivity(in); }
    }

    // ---------- Configurações > Desempenho ----------
    private void aplicarDesempenho() {
        rend.limite = Estado.i("ui_fps", 30);
        rend.leve = Estado.b("ui_perf", true);
        String cn = Estado.s("cenario", "padrao");
        if ("imagem".equals(cn) && rend.imgCeu == null) { carregarImagemCeu(); cn = "padrao"; }
        rend.cenario = cn;
        rend.semExemplo = !fixas.isEmpty();
        rend.temaJan = Temas.obter(Estado.s("ui_all", "escuro"));
        rend.temaDock = Temas.obter(Estado.s("ui_dock", "escuro"));
        rend.opJan = Estado.f("ui_op", 1f);
        rend.dockEsc = Estado.f("ui_dks", 1f);
        rend.brilho = Estado.b("ui_glow", false);
        hud.setVisibility(Estado.b("ui_hud", false) ? View.VISIBLE : View.GONE);   // "Contador de fps na tela"
        int modo = Estado.i("ui_res", 0), idx;
        if (modo >= 1 && modo <= 3) idx = modo - 1;          // Alta / Média / Baixa
        else {                                               // Auto: desce rápido se o fps cair, sobe devagar se sobrar
            float f = CenaRenderer.fps, meta = rend.limite > 0 ? rend.limite : 60f;
            if (f > 0) {
                if (f < meta * .8f) { bom = 0; if (++ruim >= 8) { autoIdx = Math.min(2, autoIdx + 1); ruim = 0; } }
                else { ruim = 0; if (f > meta * .95f) { if (++bom >= 24) { autoIdx = Math.max(0, autoIdx - 1); bom = 0; } } else bom = 0; }
            }
            idx = autoIdx;
        }
        if (idx != resAplicada && gl.getWidth() > 0) {
            resAplicada = idx;
            gl.getHolder().setFixedSize(Math.round(gl.getWidth() * ESC[idx]), Math.round(gl.getHeight() * ESC[idx]));
        }
    }

    // ---------- passthrough ----------
    private void pedirPermissao() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{android.Manifest.permission.CAMERA}, 7);
    }

    // ---------- mão (MediaPipe) ----------
    private void iniciarMao() {
        if (mao != null || !Estado.b("mao_on", true)) return;
        try {
            mao = (Mao) Class.forName("com.seuapp.mrquest.nativo.MaoMediaPipe").newInstance();
        } catch (Throwable t) {
            CenaRenderer.maoEstado = "indisponível (este APK foi compilado sem o MediaPipe)";
            return;
        }
        mao.iniciar(this, new Mao.Ouvinte() {
            @Override public void resultado(float[] xs, float[] ys) { aoMao(xs, ys); }
        });
        cam.leitor = new CamaraFundo.Leitor() {
            @Override public boolean quer() { Mao m = mao; return m != null && m.livre(); }
            @Override public void quadro(android.graphics.Bitmap b, long ts) { Mao m = mao; if (m != null) m.enviar(b, ts); }
        };
    }

    private void pararMao() {
        cam.leitor = null;
        if (mao != null) { mao.parar(); mao = null; }
        suavX = suavY = null;
        overlay.definir(null, null, false);
    }

    /** Pontos da mão (0..1 no quadro) → coordenadas de tela (-1..1), com o mesmo recorte do fundo. Beliscar (polegar+indicador) = tocar. */
    private void aoMao(float[] xs, float[] ys) {
        if (xs == null) { suavX = suavY = null; pinchAnt = false; overlay.definir(null, null, false); return; }
        float A = (float) gl.getWidth() / Math.max(1, gl.getHeight());
        int rot = rend.camRot;
        float c = rend.camAsp, eff = (rot % 180 != 0) ? 1f / c : c;
        float sx = Math.min(1f, A / eff), sy = Math.min(1f, eff / A);
        int hs = Math.max(0, Math.min(3, Estado.i("hsm", 1)));
        float a = new float[]{1f, .6f, .4f, .25f}[hs];                // suavidade da mão
        int n = xs.length;
        if (suavX == null || suavX.length != n) { suavX = new float[n]; suavY = new float[n]; System.arraycopy(xs, 0, suavX, 0, n); System.arraycopy(ys, 0, suavY, 0, n); }
        float[] nx = new float[n], ny = new float[n];
        for (int i = 0; i < n; i++) {
            suavX[i] += (xs[i] - suavX[i]) * a;
            suavY[i] += (ys[i] - suavY[i]) * a;
            nx[i] = (suavX[i] - .5f) / sx * 2f;
            ny[i] = -(suavY[i] - .5f) / sy * 2f;
        }
        // pinça: distância polegar–indicador relativa ao tamanho da palma (pulso→base do dedo médio)
        float dp = (float) Math.hypot((xs[4] - xs[8]) * eff, ys[4] - ys[8]);
        float palma = (float) Math.hypot((xs[0] - xs[9]) * eff, ys[0] - ys[9]);
        boolean pinca = palma > 1e-4f && dp / palma < .35f;
        if (pinca && !pinchAnt) {
            final float tx = nx[8], ty = ny[8];
            runOnUiThread(new Runnable() { @Override public void run() { revelarBotoes(); if (!toqueJanela(tx, ty)) tocar(tx, ty); } });
        }
        pinchAnt = pinca;
        overlay.definir(nx, ny, pinca);
    }

    private void abrirCamera() {
        if (!ativa || stCam == null || !Estado.b("cam_on", true) || !CamaraFundo.temPermissao(this)) return;
        iniciarMao();
        cam.iniciar(stCam);
        rend.camAsp = (float) cam.largura / Math.max(1, cam.altura);
        ajustarRot();
        rend.camAtiva = true;
    }

    private void fecharCamera() {
        pararMao();
        rend.camAtiva = false;
        cam.parar();
    }

    private void ajustarRot() {
        int disp = getWindowManager().getDefaultDisplay().getRotation() * 90;
        rend.camRot = ((cam.sensorOri - disp) % 360 + 360) % 360;
        cam.rotacao = rend.camRot;
        if (mao != null) CenaRenderer.maoEstado = mao.estado();
    }

    /** Arquivo HTML escolhido no navegador (📂): lê o texto e mostra na janela. */
    @Override protected void onActivityResult(int rc, int res, Intent data) {
        super.onActivityResult(rc, res, data);
        if (rc != 21 || res != RESULT_OK || data == null || data.getData() == null || nav == null) return;
        final android.net.Uri u = data.getData();
        final NavegadorView alvo = nav;
        final String nm0 = nomeDe(u);
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    if (nm0.toLowerCase().endsWith(".zip")) {
                        final java.io.File dir = Pacotes.extrairZip(CenaActivity.this, u, nm0);
                        final java.io.File idx = Pacotes.acharIndex(dir);
                        runOnUiThread(new Runnable() { @Override public void run() {
                            if (idx != null && nav == alvo) alvo.carregarArquivo(idx);
                            else Toast.makeText(CenaActivity.this, "Esse .zip não tem index.html", Toast.LENGTH_LONG).show();
                        } });
                        return;
                    }
                    java.io.InputStream in = getContentResolver().openInputStream(u);
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[8192]; int n, tot = 0;
                    while ((n = in.read(buf)) > 0 && tot < 8 * 1024 * 1024) { bo.write(buf, 0, n); tot += n; }
                    in.close();
                    final String html = bo.toString("UTF-8");
                    final String nome = nm0;
                    runOnUiThread(new Runnable() { @Override public void run() { if (nav == alvo) alvo.carregarHtml(html, nome); } });
                } catch (Throwable t) {
                    runOnUiThread(new Runnable() { @Override public void run() { Toast.makeText(CenaActivity.this, "Não consegui ler o arquivo", Toast.LENGTH_SHORT).show(); } });
                }
            }
        }).start();
    }

    private String nomeDe(android.net.Uri u) {
        String nm = u.getLastPathSegment();
        android.database.Cursor c = null;
        try {
            c = getContentResolver().query(u, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (ix >= 0) nm = c.getString(ix);
            }
        } catch (Throwable t) { } finally { if (c != null) c.close(); }
        return nm == null ? "app.html" : nm;
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        abrirCamera();
    }

    private Button botao(String t, View.OnClickListener c) {
        Button x = new Button(this);
        x.setText(t);
        x.setAllCaps(false);
        x.setTextColor(Color.WHITE);
        x.setTextSize(13);
        x.setBackgroundResource(R.drawable.bg_btn_vidro);
        x.setOnClickListener(c);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(6, 0, 6, 0);
        x.setLayoutParams(p);
        return x;
    }

    @Override protected void onResume() {
        super.onResume();
        ativa = true;
        resAplicada = -99;
        gl.onResume();
        imgTentou = false;
        rend.definirImagem(null);
        if (!fixas.isEmpty()) { h.removeCallbacks(tickFixas); h.post(tickFixas); }
        if (janApps != null) janApps.aplicarTema();
        if (janNav != null) janNav.aplicarTema();
        if (Estado.b("cam_on", true)) { pedirPermissao(); abrirCamera(); }
        if (Estado.b("6d_auto", true)) pose.iniciar();   // "Ligar o 6DOF simulado ao entrar"
        h.post(atualiza);
    }

    @Override protected void onPause() {
        ativa = false;
        fecharCamera();
        h.removeCallbacks(atualiza);
        h.removeCallbacks(tickFixas);
        h.removeCallbacks(tickCtrl);
        ctrlLoop = false;
        CenaRenderer.zerarMedicao();
        pose.parar();
        gl.onPause();
        super.onPause();
    }

    private void imersivo() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) imersivo();
    }
}
