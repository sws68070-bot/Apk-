package com.seuapp.mrquest.nativo;

/** Temas da interface (janelas e barra de baixo) — mesmas cores do mkTh() do 02-temas-cena.js. */
public final class Temas {
    private Temas() {}

    public static final class T {
        public final int bg, bar, btn, fr, dk;     // 0xRRGGBB: fundo, barra de título, botões, moldura, barra de baixo
        public final boolean claro;
        public final float[] bg3, bar3, fr3, dk3;
        T(int bg, int bar, int btn, int fr, int dk, boolean claro) {
            this.bg = bg; this.bar = bar; this.btn = btn; this.fr = fr; this.dk = dk; this.claro = claro;
            bg3 = rgb(bg); bar3 = rgb(bar); fr3 = rgb(fr); dk3 = rgb(dk);
        }
    }

    private static float[] rgb(int c) { return new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f}; }

    public static final String[] CHAVES = {"escuro", "meianoite", "roxo", "floresta", "vinho", "grafite", "claro"};
    private static final T[] LISTA = {
        new T(0x20242d, 0x14171d, 0x2b303b, 0x2a2e38, 0x14161c, false),
        new T(0x141b33, 0x0b1024, 0x232e52, 0x1c2648, 0x0b1024, false),
        new T(0x2a2140, 0x191229, 0x3d3060, 0x3a2d5c, 0x191229, false),
        new T(0x1c2e26, 0x101c17, 0x2a4438, 0x27423a, 0x101c17, false),
        new T(0x3a1f2b, 0x241019, 0x57303f, 0x522a3a, 0x241019, false),
        new T(0x2f3136, 0x1f2124, 0x41444b, 0x44474e, 0x1f2124, false),
        new T(0xe9edf5, 0xcdd5e4, 0xc2cbdc, 0xb8c2d6, 0xaab4c8, true)};

    public static T obter(String k) {
        for (int i = 0; i < CHAVES.length; i++) if (CHAVES[i].equals(k)) return LISTA[i];
        return LISTA[0];
    }
}
