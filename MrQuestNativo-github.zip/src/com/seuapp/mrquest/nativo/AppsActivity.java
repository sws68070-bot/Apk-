package com.seuapp.mrquest.nativo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** "Apps instalados" em tela cheia (a cena usa a mesma grade numa janela flutuante). */
public class AppsActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        float d = getResources().getDisplayMetrics().density;

        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(0xFF0A0C12);
        raiz.setPadding((int) (16 * d), (int) (12 * d), (int) (16 * d), 0);

        LinearLayout topo = new LinearLayout(this);
        topo.setOrientation(LinearLayout.HORIZONTAL);
        topo.setGravity(Gravity.CENTER_VERTICAL);
        TextView voltar = new TextView(this);
        voltar.setText("‹ Voltar");
        voltar.setTextColor(0xFF5B8CFF);
        voltar.setTextSize(16);
        voltar.setPadding(0, (int) (6 * d), (int) (16 * d), (int) (6 * d));
        voltar.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { finish(); } });
        TextView titulo = new TextView(this);
        titulo.setText("Apps instalados");
        titulo.setTextColor(Color.WHITE);
        titulo.setTextSize(18);
        topo.addView(voltar);
        topo.addView(titulo);
        raiz.addView(topo);

        AppsGrade grade = new AppsGrade(this, 92, new AppsGrade.Ouvinte() {
            @Override public void abrir(String pacote, String nome) {
                Intent in = getPackageManager().getLaunchIntentForPackage(pacote);
                if (in != null) startActivity(in);
                else Toast.makeText(AppsActivity.this, "Não foi possível abrir", Toast.LENGTH_SHORT).show();
            }
        });
        raiz.addView(grade, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(raiz);
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
}
