package com.seuapp.mrquest.nativo;

import android.content.Context;
import android.content.SharedPreferences;

/** Preferências salvas (equivale ao localStorage / objeto S.ui do 01-estado.js). */
public final class Estado {
    private static SharedPreferences sp;

    private Estado() {}

    public static synchronized void init(Context c) {
        if (sp == null) sp = c.getApplicationContext().getSharedPreferences("mrquest", Context.MODE_PRIVATE);
    }

    public static int i(String k, int d) { return sp.getInt(k, d); }
    public static float f(String k, float d) { return sp.getFloat(k, d); }
    public static boolean b(String k, boolean d) { return sp.getBoolean(k, d); }
    public static String s(String k, String d) { return sp.getString(k, d); }

    public static void put(String k, int v) { sp.edit().putInt(k, v).apply(); }
    public static void put(String k, float v) { sp.edit().putFloat(k, v).apply(); }
    public static void put(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    public static void put(String k, String v) { sp.edit().putString(k, v).apply(); }

    public static void remover(String prefixo) {
        SharedPreferences.Editor e = sp.edit();
        for (String k : sp.getAll().keySet()) if (k.startsWith(prefixo)) e.remove(k);
        e.apply();
    }

    public static float limitar(float v, float mn, float mx) { return Math.max(mn, Math.min(mx, v)); }
    public static float arred(float v) { return Math.round(v * 100f) / 100f; }
}
