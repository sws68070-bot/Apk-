package com.seuapp.mrquest.nativo;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** ⚙ Configurações — porte nativo do 22-config.js, com a seção do 6DOF simulado. */
public class ConfigActivity extends Activity {

    interface Acao { void ok(); }
    interface Liga { void ao(boolean v); }
    interface Escolha { void ao(int i); }

    // ---- listas do original ----
    private static final int[] FPS_OPT = {30, 40, 50, 60, 0};
    private static final String[] RES_NOM = {"Auto", "Alta", "Média", "Baixa"};
    private static final String[] HSM_NOM = {"Rápida", "Normal", "Suave"};
    private static final String[] SENS_NOM = {"Normal", "Alta", "Máxima"};
    private static final String[] HCOLS = {"Azul", "Verde", "Rosa", "Branco", "Laranja"};
    private static final String[] TEMAS_K = {"escuro", "meianoite", "roxo", "floresta", "vinho", "grafite", "claro"};
    private static final String[] TEMAS_N = {"Escuro", "Meia-noite", "Roxo", "Floresta", "Vinho", "Grafite", "Claro"};
    private static final String[] AT_NOM = {"Básico", "Médio", "Forte"};
    // preset: {id, fps, res, perf, r, l, det, hn}
    private static final String[] PRE_NOM = {"Economia", "Equilibrado", "Qualidade"};
    private static final int[][] PRE = {
            {30, 3, 1, 15, 8, 256, 1},
            {40, 0, 0, 25, 15, 256, 0},
            {60, 1, 0, 30, 20, 320, 0}};

    private static final int REQ_GPS = 10, REQ_ARQ = 20;

    private ScrollView rolagem;
    private LinearLayout corpo;
    private TextView info;
    private Pose6Dof pose;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable atualizaInfo = new Runnable() {
        @Override public void run() {
            if (info != null) info.setText(pose.status());
            h.postDelayed(this, 500);
        }
    };

    // ================= ciclo de vida =================
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Estado.init(this);
        pose = Pose6Dof.get(this);

        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(cor(R.color.cfg_fundo));

        // cabeçalho
        LinearLayout hd = new LinearLayout(this);
        hd.setOrientation(LinearLayout.HORIZONTAL);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        hd.setPadding(dp(14), dp(12), dp(14), dp(12));
        TextView tit = new TextView(this);
        tit.setText("⚙ Configurações");
        tit.setTextColor(Color.WHITE);
        tit.setTextSize(17);
        tit.setTypeface(Typeface.DEFAULT_BOLD);
        hd.addView(tit, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        hd.addView(chip("✕ Fechar", false, new Acao() { public void ok() { finish(); } }));
        raiz.addView(hd);
        View ln = new View(this);
        ln.setBackgroundColor(0x33FFFFFF);
        raiz.addView(ln, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));

        rolagem = new ScrollView(this);
        corpo = new LinearLayout(this);
        corpo.setOrientation(LinearLayout.VERTICAL);
        corpo.setPadding(dp(14), dp(4), dp(14), dp(40));
        rolagem.addView(corpo);
        raiz.addView(rolagem, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(raiz);
        montar();
    }

    @Override protected void onResume() {
        super.onResume();
        pose.iniciar();            // o painel mostra o 6DOF ao vivo
        h.post(atualizaInfo);
        imersivo();
    }

    @Override protected void onPause() {
        h.removeCallbacks(atualizaInfo);
        pose.parar();
        super.onPause();
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) imersivo(); }

    private void imersivo() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    // ================= conteúdo =================
    private void montar() {
        final int y = rolagem.getScrollY();
        corpo.removeAllViews();
        info = null;

        secao6dof();
        secaoDesempenho();
        secaoMao();
        secaoVisao();
        secaoInterface();
        secaoArquivos();

        rolagem.post(new Runnable() { public void run() { rolagem.scrollTo(0, y); } });
    }

    private void redesenhar() { montar(); }

    // ---------------- 6DOF simulado ----------------
    private void secao6dof() {
        corpo.addView(h4("6DOF simulado"));
        boolean on = Estado.b("6d_on", true);
        boolean gps = "gps".equals(Estado.s("6d_modo", "passos"));

        corpo.addView(tog("Janelas fixas no espaço (6DOF simulado)", on, new Liga() { public void ao(boolean v) {
            Estado.put("6d_on", v); pose.recarregar(); }},
            "Liga o 6DOF simulado: a cabeça gira pelo giroscópio e anda pelos seus passos (ou GPS). As janelas fixadas ficam paradas no ar enquanto você anda ou vira o celular."));

        corpo.addView(seg("Como a posição é medida", new String[]{"Passos (acelerômetro)", "GPS"}, gps ? 1 : 0, new Escolha() { public void ao(int i) {
            Estado.put("6d_modo", i == 1 ? "gps" : "passos");
            if (i == 1) pedirGps();
            pose.reiniciar(); pose.zerar(); }},
            "Passos: conta cada passo e anda para onde o olhar aponta. GPS: usa o deslocamento real (precisa de céu aberto e de bússola, e ~6 m de caminhada para o sinal firmar)."));

        corpo.addView(seg("Sentido dos passos", new String[]{"Frente", "Trás (de ré)"}, Estado.i("6d_sent", 1) >= 0 ? 0 : 1, new Escolha() { public void ao(int i) {
            Estado.put("6d_sent", i == 0 ? 1 : -1); pose.recarregar(); }},
            "Sem a câmera nativa o app não sabe se você anda pra frente ou pra trás; aqui você escolhe. (A detecção automática pela câmera volta quando ela entrar.)"));

        corpo.addView(rotulado("Vista de cima (você, o que andou e pra onde olha)", new MiniMapaView(this), null));

        corpo.addView(seg("Ações", new String[]{"↺ Recentrar", "↺ Zerar rastreio", "▲ Passo à frente (teste)", "▼ Passo atrás (teste)",
                pose.calOn ? "📏 Toque ao chegar (" + pose.calPassos + " passos)" : "📏 Calibrar distância", "Padrões do 6DOF"}, pose.calOn ? 4 : -1,
                new Escolha() { public void ao(int i) {
                    switch (i) {
                        case 0: pose.recentrar(); toast("Visão recentrada"); break;
                        case 1: pose.zerar(); toast("Rastreio zerado"); break;
                        case 2: pose.passoManual(1); break;
                        case 3: pose.passoManual(-1); break;
                        case 4: toast(pose.calibrar()); redesenhar(); break;
                        case 5: pose.padroes(); toast("Padrões do 6DOF restaurados"); redesenhar(); break;
                    }
                }}, null));

        corpo.addView(stepF("Escala do movimento", "6d_esc", 1f, .1f, .2f, 3f, "%"));
        corpo.addView(stepF("Ganho de avanço", "6d_gfw", 1f, .05f, .4f, 2.5f, ""));
        corpo.addView(stepF("Ganho de giro", "6d_grt", 1f, .05f, .4f, 2.5f, ""));
        corpo.addView(stepF("Altura da câmera (m)", "6d_hh", 1.4f, .05f, .5f, 2.2f, ""));
        corpo.addView(stepF("Passo (m)", "6d_plen", .65f, .05f, .3f, 1.2f, ""));
        corpo.addView(stepF("Sensibilidade do passo (limiar, m/s²)", "6d_psl", 1f, .1f, .4f, 3f, ""));
        corpo.addView(stepF("Pé-direito (m, 0 = sem teto)", "6d_hcl", 2.6f, .1f, 0f, 6f, ""));
        corpo.addView(stepF("Distância real da calibração (m)", "6d_cdr", 2f, .5f, .5f, 10f, ""));

        corpo.addView(togE("Ligar o 6DOF simulado ao entrar", "6d_auto", true, "Quando você toca em Entrar, o 6DOF simulado liga sozinho."));
        corpo.addView(togE("Travar altura (anti-subida)", "6d_vlk", true, "Celular na mão não sobe nem desce de verdade: segura a altura."));
        corpo.addView(togE("Mover na vertical (subir/descer)", "6d_vert", true, null));
        corpo.addView(togE("Subir/descer pelo acelerômetro", "6d_vacc", true, "Só vale com a altura destravada. Parado ~0,3 s a altura trava."));
        corpo.addView(togE("Detecção de \"parado\" (trava a janela com o celular firme)", "6d_stl", true,
                "Com o celular firme, o giro só passa se ultrapassar uma zona de repouso (~0,12°): sem tremor, sem \"respirar\". Ao mover de verdade, solta na hora."));
        corpo.addView(stepF("Sensibilidade do \"parado\"", "6d_stk", 1f, .25f, .5f, 2.5f, "%"));
        corpo.addView(tog("Usar a bússola no giro (norte de verdade)", Estado.b("6d_bussola", false), new Liga() { public void ao(boolean v) {
            Estado.put("6d_bussola", v); pose.reiniciar(); }},
            "Liga o vetor de rotação com bússola (sem deriva lateral, mas pode oscilar perto de metal/imãs). O modo GPS sempre usa."));

        info = new TextView(this);
        info.setTextSize(13);
        info.setTextColor(0xFFCBD5E1);
        info.setLineSpacing(0, 1.15f);
        info.setText(pose.status());
        corpo.addView(rotulado("Estado", info, null));
    }

    private void pedirGps() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_GPS);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_GPS) pose.reiniciar();
    }

    // ---------------- Desempenho ----------------
    private int presetAtual() {
        for (int i = 0; i < PRE.length; i++) {
            int[] p = PRE[i];
            if (Estado.i("ui_fps", 30) == p[0] && Estado.i("ui_res", 0) == p[1] && Estado.b("ui_perf", true) == (p[2] == 1)
                    && Estado.i("skipR", 20) == p[3] && Estado.i("skipL", 10) == p[4]
                    && Estado.i("detr", 256) == p[5] && Estado.i("hn", 0) == p[6]) return i;
        }
        return -1;
    }

    private void aplicarPreset(int i) {
        int[] p = PRE[i];
        Estado.put("ui_fps", p[0]); Estado.put("ui_res", p[1]); Estado.put("ui_perf", p[2] == 1);
        Estado.put("skipR", p[3]); Estado.put("skipL", p[4]); Estado.put("detr", p[5]); Estado.put("hn", p[6]);
    }

    private void secaoDesempenho() {
        corpo.addView(h4("Desempenho"));
        int tier = Estado.i("at_tier", -1);
        String ult = tier >= 0 ? "Última medida: " + AT_NOM[tier] + " (" + Estado.s("at_last", "") + "). " : "";
        corpo.addView(seg("Otimização automática", new String[]{"⚡ Otimizar para este aparelho", "Padrão recomendado"}, -1, new Escolha() { public void ao(int i) {
            if (i == 0) otimizar(); else { aplicarPreset(1); toast("Padrão recomendado aplicado"); redesenhar(); } }},
            ult + "Avalia núcleos e memória do aparelho e escolhe a predefinição, a resolução da detecção e o nº de mãos. (A medição por fps volta quando o motor 3D nativo entrar.)"));
        corpo.addView(seg("Predefinição", PRE_NOM, presetAtual(), new Escolha() { public void ao(int i) { aplicarPreset(i); redesenhar(); } },
                "Economia = menos fps/resolução e detecção mais leve · Qualidade = o contrário."));
        String[] fps = new String[FPS_OPT.length];
        int sf = -1; int cf = Estado.i("ui_fps", 30);
        for (int i = 0; i < FPS_OPT.length; i++) { fps[i] = FPS_OPT[i] > 0 ? FPS_OPT[i] + " fps" : "Livre"; if (FPS_OPT[i] == cf) sf = i; }
        corpo.addView(seg("Limite de quadros", fps, sf, new Escolha() { public void ao(int i) { Estado.put("ui_fps", FPS_OPT[i]); redesenhar(); } }, null));
        corpo.addView(seg("Resolução", RES_NOM, Estado.i("ui_res", 0), new Escolha() { public void ao(int i) { Estado.put("ui_res", i); redesenhar(); } },
                "Auto desce e sobe sozinha conforme o fps."));
        corpo.addView(togE("Modo desempenho", "ui_perf", true, null));
        corpo.addView(togE("Contador de fps na tela", "ui_hud", false, null));
    }

    private void otimizar() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        double gb = mi.totalMem / 1073741824.0;
        int nuc = Runtime.getRuntime().availableProcessors();
        int tier = (gb >= 7 && nuc >= 8) ? 2 : (gb >= 3.5 && nuc >= 6) ? 1 : 0;
        aplicarPreset(tier);
        Estado.put("at_tier", tier);
        Estado.put("at_last", String.format(new Locale("pt", "BR"), "%d núcleos, %.1f GB", nuc, gb));
        toast("Otimizado: " + AT_NOM[tier]);
        redesenhar();
    }

    // ---------------- Mão ----------------
    private void secaoMao() {
        corpo.addView(h4("Mão"));
        corpo.addView(fpsRow("Detecções da mão direita (mira/clique)", "skipR", 20,
                "Quantas vezes por segundo a mão é detectada. Mais = acompanha melhor, mas pesa mais no aparelho. Auto ajusta sozinho. Máximo 30 (limite da câmera)."));
        corpo.addView(fpsRow("Detecções da mão esquerda", "skipL", 10, null));
        corpo.addView(seg("Suavidade da mão", HSM_NOM, Estado.i("hsm", 1), new Escolha() { public void ao(int i) { Estado.put("hsm", i); redesenhar(); } },
                "Suave = menos tremor, um pouco mais de atraso."));
        int hn = Estado.i("hn", 0);
        corpo.addView(seg("Mãos detectadas", new String[]{"Auto", "1 mão (mais rápido)", "2 mãos"}, hn, new Escolha() { public void ao(int i) { Estado.put("hn", i); redesenhar(); } },
                "Auto = começa com 2 mãos e passa sozinho pra 1 mão se o aparelho ficar lento. Com 1 mão a detecção fica bem mais leve, mas só uma mão é seguida por vez."));
        corpo.addView(seg("Sensibilidade da detecção", SENS_NOM, Estado.i("sens", 1), new Escolha() { public void ao(int i) { Estado.put("sens", i); redesenhar(); } },
                "Alta (padrão) e Máxima aceitam mãos mais difíceis (longe, escuro, borrada). Máxima pode confundir objeto com mão."));
        corpo.addView(togE("Alcance estendido (mão longe)", "zoom", true,
                "Quando a mão some, tenta de novo num recorte ampliado da imagem: acha a mão mais longe da câmera."));
        String[] del = {"AUTO", "BOTH", "GPU", "CPU"};
        String cd = Estado.s("hdel", "AUTO"); int sd = 0;
        for (int i = 0; i < del.length; i++) if (del[i].equals(cd)) sd = i;
        corpo.addView(seg("Processador da detecção", new String[]{"Automático (recomendado)", "GPU + CPU (os dois)", "Só GPU", "Só CPU"}, sd,
                new Escolha() { public void ao(int i) { Estado.put("hdel", del[i]); redesenhar(); } },
                "Automático: testa GPU e CPU e fica com o mais rápido. GPU + CPU: usa os dois (mais memória e bateria)."));
        float palma = Estado.f("palma", .09f);
        corpo.addView(seg("Tamanho da sua mão (distância)", new String[]{"Calibrar agora", "Padrão (9 cm)"}, Math.abs(palma - .09f) < 1e-4 ? 1 : -1,
                new Escolha() { public void ao(int i) {
                    if (i == 0) toast("A calibração usa a câmera — chega junto com a câmera nativa");
                    else { Estado.put("palma", .09f); redesenhar(); } }},
                "Atual: palma de " + String.format(new Locale("pt", "BR"), "%.1f", palma * 100) + " cm. Deixa a profundidade (perto/longe) mais certa."));
        corpo.addView(seg("Resolução da detecção", new String[]{"256 (padrão)", "320 (mais preciso)"}, Estado.i("detr", 256) == 320 ? 1 : 0,
                new Escolha() { public void ao(int i) { Estado.put("detr", i == 1 ? 320 : 256); redesenhar(); } },
                "320 acompanha melhor os dedos, mas pesa mais e gasta mais bateria."));
        corpo.addView(togE("Câmera a 60 fps (experimental)", "cam60", false, "Só ajuda se o celular entregar 60 fps na câmera; no escuro costuma cair sozinha."));
        corpo.addView(togE("Esqueleto da mão visível", "ui_skel", true, null));
        corpo.addView(stepF("Opacidade da mão", "ui_hop", .9f, .1f, .2f, 1f, "%"));
        corpo.addView(seg("Cor da mão", HCOLS, Estado.i("hcol", 0), new Escolha() { public void ao(int i) { Estado.put("hcol", i); redesenhar(); } }, null));
    }

    private View fpsRow(String lbl, final String k, int def, String nota) {
        int v = Estado.i(k, def);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        final TextView val = new TextView(this);
        val.setTextColor(Color.WHITE); val.setTypeface(Typeface.DEFAULT_BOLD); val.setTextSize(12);
        val.setText(v > 0 ? v + " vezes por segundo" : "Auto");
        col.addView(val);
        SeekBar sb = new SeekBar(this);
        sb.setMax(30); sb.setProgress(v);
        sb.getProgressDrawable().setColorFilter(0xFF5B8CFF, PorterDuff.Mode.SRC_IN);
        sb.getThumb().setColorFilter(0xFF5B8CFF, PorterDuff.Mode.SRC_IN);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                Estado.put(k, p); val.setText(p > 0 ? p + " vezes por segundo" : "Auto"); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) { redesenhar(); }
        });
        col.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));
        int[] at = {0, 10, 15, 20, 25, 30};
        String[] nm = new String[at.length]; int sel = -1;
        for (int i = 0; i < at.length; i++) { nm[i] = at[i] > 0 ? at[i] + " fps" : "Auto"; if (at[i] == v) sel = i; }
        col.addView(seg("Atalhos", nm, sel, new Escolha() { public void ao(int i) { Estado.put(k, at[i]); redesenhar(); } }, null));
        return rotulado(lbl, col, nota);
    }

    // ---------------- Visão ----------------
    private void secaoVisao() {
        corpo.addView(h4("Visão"));
        corpo.addView(seg("Suavidade da visão (anti-tremedeira)", new String[]{"Desligada", "Leve", "Média", "Forte"}, Estado.i("vs", 2),
                new Escolha() { public void ao(int i) { Estado.put("vs", i); pose.recarregar(); redesenhar(); } },
                "Forte = bem firme, mas vira um pouco mais devagar."));
        corpo.addView(stepF("Campo de visão", "fov", 80f, 2f, 56f, 110f, "°"));
        corpo.addView(stepF("Distância das janelas", "dist", 1.15f, .05f, .7f, 2.2f, "%"));
        corpo.addView(seg("Direção", new String[]{"Recentrar"}, -1, new Escolha() { public void ao(int i) { pose.recentrar(); toast("Visão recentrada"); } }, null));
        corpo.addView(togE("Controle (PS4 / Xbox)", "ctrl_on", true,
                "Analógico esquerdo anda, direito gira. ✕ ou R2 clica no + do centro. △ recentra, □ organiza as janelas, L1 apps, R1 navegador, ○ oculta botões, Options abre as Configurações."));
        corpo.addView(seg("Cenário (céu, chão e grade)", Cenarios.NOMES, Cenarios.indice(Estado.s("cenario", "padrao")),
                new Escolha() { public void ao(int i) { Estado.put("cenario", Cenarios.CHAVES[i]); redesenhar(); } },
                "Vale na cena sem a câmera de fundo. Com o passthrough ligado, o ambiente real aparece no lugar."));
    }

    // ---------------- Interface ----------------
    private void secaoInterface() {
        corpo.addView(h4("Interface"));
        corpo.addView(seg("Tema das janelas", TEMAS_N, indice(TEMAS_K, Estado.s("ui_all", "escuro")), new Escolha() { public void ao(int i) { Estado.put("ui_all", TEMAS_K[i]); redesenhar(); } }, null));
        corpo.addView(seg("Tema da barra de baixo", TEMAS_N, indice(TEMAS_K, Estado.s("ui_dock", "escuro")), new Escolha() { public void ao(int i) { Estado.put("ui_dock", TEMAS_K[i]); redesenhar(); } }, null));
        corpo.addView(stepF("Transparência das janelas", "ui_op", 1f, .05f, .4f, 1f, "%"));
        corpo.addView(stepF("Tamanho da barra de baixo", "ui_dks", 1f, .1f, .6f, 1.6f, "%"));
        corpo.addView(stepF("Tamanho do texto", "ui_txt", 1f, .1f, .7f, 1.6f, "%"));
        corpo.addView(togE("Brilho de destaque (dourado)", "ui_glow", false, null));
        corpo.addView(togE("Sons e vibração", "ui_snd", true, "Vale ao tocar nos ícones do dock e nas janelas."));
    }

    // ---------------- Arquivos ----------------
    private void secaoArquivos() {
        corpo.addView(h4("Arquivos"));
        corpo.addView(seg("Adicionar ao app (escolha o arquivo no celular)", new String[]{"🧩 Plugin (.zip)", "🌄 Cenário (imagem ou .zip)", "📦 App (.zip / .json)"}, -1,
                new Escolha() { public void ao(int i) { escolherArquivo(i); } },
                "Plugin: .zip do Quest Studio (ou com plugin.js dentro). Cenário: imagem de fundo ou .zip com modelos 3D. App: arquivo exportado do Criar app."));
        corpo.addView(seg("Modelo 3D (.glb) no lugar do desenho padrão", new String[]{"Janelas", "Barra de baixo"}, -1,
                new Escolha() { public void ao(int i) { escolherArquivo(3 + i); } }, null));
    }

    private static final String[] ARQ_NOM = {"plugin", "cenario", "app", "glb_janelas", "glb_dock"};

    private void escolherArquivo(int i) {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("*/*");
        it.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(it, "Escolher arquivo"), REQ_ARQ + i);
    }

    @Override
    protected void onActivityResult(int code, int res, Intent data) {
        super.onActivityResult(code, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        int i = code - REQ_ARQ;
        if (i < 0 || i >= ARQ_NOM.length) return;
        Uri u = data.getData();
        String nome = u.getLastPathSegment();
        Cursor c = null;
        try {
            c = getContentResolver().query(u, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ix >= 0) nome = c.getString(ix);
            }
        } catch (Exception ignore) { } finally { if (c != null) c.close(); }
        Estado.put("arq_" + ARQ_NOM[i], u.toString());
        final String nm = nome == null ? "arquivo" : nome;
        final Uri uf = u;
        final int tipo = i;
        if (tipo == 1 || tipo == 0 || tipo == 2) {   // cenário, plugin, app: processa em segundo plano
            new Thread(new Runnable() {
                @Override public void run() {
                    String m;
                    try {
                        boolean zip = nm.toLowerCase().endsWith(".zip");
                        if (tipo == 1) {
                            boolean ok = false;
                            if (zip) {
                                java.io.File img = Pacotes.primeiraImagem(Pacotes.extrairZip(ConfigActivity.this, uf, "cenario_" + nm));
                                if (img != null) ok = Pacotes.salvarImagemCeu(ConfigActivity.this, new java.io.FileInputStream(img));
                            } else ok = Pacotes.salvarImagemCeu(ConfigActivity.this, getContentResolver().openInputStream(uf));
                            if (ok) Estado.put("cenario", "imagem");
                            m = ok ? "Cenário definido: " + nm + " (veja em Visão > Cenário)" : "Não consegui usar como cenário. Use uma imagem JPG/PNG, de preferência panorâmica 2:1.";
                        } else if (zip) {
                            java.io.File idx = Pacotes.acharIndex(Pacotes.extrairZip(ConfigActivity.this, uf, nm));
                            m = idx != null ? "Instalado: " + nm + " — abra na cena pelo navegador (📦)" : "Esse .zip não tem index.html";
                        } else m = "Recebido: " + nm + " (para app/plugin use um .zip com index.html)";
                    } catch (Throwable t) { m = "Falha ao ler o arquivo"; }
                    final String msg = m;
                    runOnUiThread(new Runnable() { @Override public void run() { toast(msg); redesenhar(); } });
                }
            }).start();
            return;
        }
        toast("Recebido: " + nome + " — será usado quando a etapa de arquivos entrar");
    }

    // ================= componentes (equivalem às classes do #cfg do CSS) =================
    private TextView h4(String t) {
        TextView v = new TextView(this);
        v.setText(t.toUpperCase(new Locale("pt", "BR")));
        v.setTextSize(12);
        v.setTextColor(cor(R.color.cfg_titulo_secao));
        v.setLetterSpacing(.08f);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(0, dp(18), 0, dp(6));
        return v;
    }

    private LinearLayout rotulado(String lbl, View conteudo, String nota) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(8), 0, dp(8));
        View borda = new View(this);
        borda.setBackgroundColor(cor(R.color.cfg_linha));
        r.addView(borda, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
        TextView l = new TextView(this);
        l.setText(lbl); l.setTextSize(12); l.setTextColor(cor(R.color.cfg_rotulo));
        l.setPadding(0, dp(8), 0, dp(6));
        r.addView(l);
        r.addView(conteudo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (nota != null) {
            TextView n = new TextView(this);
            n.setText(nota); n.setTextSize(11); n.setTextColor(cor(R.color.cfg_nota));
            n.setLineSpacing(0, 1.15f);
            n.setPadding(0, dp(6), 0, 0);
            r.addView(n);
        }
        return r;
    }

    private Button chip(String t, boolean on, final Acao a) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTextColor(Color.WHITE);
        b.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        b.setBackgroundResource(on ? R.drawable.bg_chip_on : R.drawable.bg_chip);
        b.setStateListAnimator(null);
        b.setMinHeight(dp(38)); b.setMinimumHeight(dp(38)); b.setMinWidth(0); b.setMinimumWidth(0);
        b.setPadding(dp(12), dp(9), dp(12), dp(9));
        b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { a.ok(); } });
        return b;
    }

    private View seg(String lbl, String[] nomes, int sel, final Escolha cb, String nota) {
        FlowLayout f = new FlowLayout(this).modo(dp(6), false);
        for (int i = 0; i < nomes.length; i++) {
            final int idx = i;
            f.addView(chip(nomes[i], i == sel, new Acao() { public void ok() { cb.ao(idx); } }));
        }
        return rotulado(lbl, f, nota);
    }

    private View tog(String lbl, final boolean v, final Liga cb, String nota) {
        return seg(lbl, new String[]{"Ligado", "Desligado"}, v ? 0 : 1, new Escolha() { public void ao(int i) {
            boolean novo = i == 0;
            if (novo != v) { cb.ao(novo); redesenhar(); } }}, nota);
    }

    private View togE(String lbl, final String key, boolean def, String nota) {
        return tog(lbl, Estado.b(key, def), new Liga() { public void ao(boolean v) { Estado.put(key, v); pose.recarregar(); } }, nota);
    }

    private View step(String lbl, String valor, final Acao menos, final Acao mais) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        Button m = chip("−", false, new Acao() { public void ok() { menos.ok(); redesenhar(); } });
        Button p = chip("+", false, new Acao() { public void ok() { mais.ok(); redesenhar(); } });
        m.setTextSize(18); p.setTextSize(18);
        m.setMinWidth(dp(44)); p.setMinWidth(dp(44));
        m.setPadding(0, 0, 0, 0); p.setPadding(0, 0, 0, 0);
        TextView v = new TextView(this);
        v.setText(valor); v.setTextColor(Color.WHITE); v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER); v.setMinWidth(dp(56));
        l.addView(m, new LinearLayout.LayoutParams(dp(44), dp(38)));
        l.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        l.addView(p, new LinearLayout.LayoutParams(dp(44), dp(38)));
        ((LinearLayout.LayoutParams) v.getLayoutParams()).setMargins(dp(10), 0, dp(10), 0);
        return rotulado(lbl, l, null);
    }

    /** Stepper ligado a uma chave float. sufixo "%" mostra valor*100; "°" mostra inteiro; "" mostra 2 casas. */
    private View stepF(String lbl, final String k, final float def, final float passo, final float mn, final float mx, final String suf) {
        float v = Estado.f(k, def);
        String txt;
        if ("%".equals(suf)) txt = Math.round(v * 100) + "%";
        else if ("°".equals(suf)) txt = Math.round(v) + "°";
        else txt = String.format(new Locale("pt", "BR"), "%.2f", v);
        return step(lbl, txt,
                new Acao() { public void ok() { Estado.put(k, Estado.limitar(Estado.arred(Estado.f(k, def) - passo), mn, mx)); pose.recarregar(); } },
                new Acao() { public void ok() { Estado.put(k, Estado.limitar(Estado.arred(Estado.f(k, def) + passo), mn, mx)); pose.recarregar(); } });
    }

    // ================= utilitários =================
    private static int indice(String[] a, String v) { for (int i = 0; i < a.length; i++) if (a[i].equals(v)) return i; return 0; }
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private int cor(int id) { return getResources().getColor(id); }
    private void toast(String t) { Toast.makeText(this, t, Toast.LENGTH_SHORT).show(); }
}
