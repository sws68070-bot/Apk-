package com.seuapp.mrquest.nativo;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Janela flutuante nativa por cima da cena: barra de título (arrastar), botão ✕ e canto ◢ (redimensionar).
 * Deve ser filha de um FrameLayout (usa as margens para se posicionar).
 */
public class JanelaFlutuante extends FrameLayout {
    public interface Ouvinte { void aoFechar(JanelaFlutuante j); }

    public Ouvinte ouvinte;
    /** Chamado ao tocar em 📌 (a cena fixa/solta a janela no ambiente). */
    public Runnable aoFixar;
    public boolean fixada;
    private TextView pinBtn;
    private final float d;
    private final TextView titulo;
    private final GradientDrawable bg;
    private final LinearLayout barra;
    private final TextView xBtn;
    private final FrameLayout conteudo;
    private final int minL, minA;
    private float ix, iy;
    private int ml, mt, w0, h0;

    public JanelaFlutuante(Context ctx, String tit) {
        super(ctx);
        d = ctx.getResources().getDisplayMetrics().density;
        minL = (int) (220 * d);
        minA = (int) (160 * d);

        bg = new GradientDrawable();
        bg.setColor(0xEE0F1320);
        bg.setCornerRadius(14 * d);
        bg.setStroke(Math.max(1, (int) d), 0x445B8CFF);
        setBackgroundDrawable(bg);
        setPadding(0, 0, 0, 0);

        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        addView(col, new FrameLayout.LayoutParams(-1, -1));

        // barra de título
        barra = new LinearLayout(ctx);
        barra.setOrientation(LinearLayout.HORIZONTAL);
        barra.setGravity(Gravity.CENTER_VERTICAL);
        barra.setPadding((int) (12 * d), 0, 0, 0);
        titulo = new TextView(ctx);
        titulo.setText(tit);
        titulo.setTextColor(Color.WHITE);
        titulo.setTextSize(13);
        titulo.setSingleLine(true);
        barra.addView(titulo, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView pin = new TextView(ctx);
        pinBtn = pin;
        pin.setText("📌");
        pin.setTextSize(14);
        pin.setGravity(Gravity.CENTER);
        pin.setAlpha(.55f);
        pin.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (aoFixar != null) aoFixar.run(); }
        });
        barra.addView(pin, new LinearLayout.LayoutParams((int) (40 * d), (int) (38 * d)));
        TextView x = new TextView(ctx);
        xBtn = x;
        x.setText("✕");
        x.setTextColor(0xFFDDE6FF);
        x.setTextSize(16);
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { fechar(); }
        });
        barra.addView(x, new LinearLayout.LayoutParams((int) (44 * d), (int) (38 * d)));
        col.addView(barra, new LinearLayout.LayoutParams(-1, (int) (38 * d)));
        barra.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) { return arrastar(e); }
        });

        conteudo = new FrameLayout(ctx);
        conteudo.setPadding((int) (6 * d), 0, (int) (6 * d), (int) (6 * d));
        col.addView(conteudo, new LinearLayout.LayoutParams(-1, 0, 1f));

        // canto de redimensionar
        TextView canto = new TextView(ctx);
        canto.setText("◢");
        canto.setTextColor(0x99DDE6FF);
        canto.setTextSize(14);
        canto.setGravity(Gravity.CENTER);
        canto.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) { return redimensionar(e); }
        });
        addView(canto, new FrameLayout.LayoutParams((int) (34 * d), (int) (34 * d), Gravity.BOTTOM | Gravity.END));
        aplicarTema();
    }

    /** Aplica Configurações > Interface: tema, transparência, tamanho do texto e brilho dourado. */
    public void aplicarTema() {
        Estado.init(getContext());
        Temas.T t = Temas.obter(Estado.s("ui_all", "escuro"));
        float op = Estado.f("ui_op", 1f);
        bg.setColor((Math.round(0xEE * op) << 24) | (t.bg & 0xFFFFFF));
        bg.setStroke(Math.max(1, (int) d), Estado.b("ui_glow", false) ? 0xCCFFC933 : 0x445B8CFF);
        GradientDrawable b = new GradientDrawable();
        b.setColor((Math.round(0xF2 * op) << 24) | (t.bar & 0xFFFFFF));
        float r = 14 * d;
        b.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        barra.setBackgroundDrawable(b);
        int tx = t.claro ? 0xFF0F172A : Color.WHITE;
        titulo.setTextColor(tx);
        xBtn.setTextColor(tx);
        titulo.setTextSize(13 * Estado.f("ui_txt", 1f));
    }

    public void definirConteudo(View v) {
        conteudo.removeAllViews();
        conteudo.addView(v, new FrameLayout.LayoutParams(-1, -1));
    }

    /** Chamado pela cena quando a janela é fixada/solta no ambiente. */
    public void marcarFixada(boolean v) { fixada = v; if (pinBtn != null) pinBtn.setAlpha(v ? 1f : .55f); }

    public void titulo(String t) { titulo.setText(t); }

    /** Cria a janela dentro de {@code pai}, centralizada, com o tamanho em dp. */
    public void mostrarEm(FrameLayout pai, int largDp, int altDp) {
        int pw = pai.getWidth() > 0 ? pai.getWidth() : getResources().getDisplayMetrics().widthPixels;
        int ph = pai.getHeight() > 0 ? pai.getHeight() : getResources().getDisplayMetrics().heightPixels;
        int w = Math.min((int) (largDp * d), pw), h = Math.min((int) (altDp * d), ph);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h, Gravity.TOP | Gravity.START);
        lp.leftMargin = (pw - w) / 2;
        lp.topMargin = (ph - h) / 2;
        pai.addView(this, lp);
    }

    public void fechar() {
        ViewGroup p = (ViewGroup) getParent();
        if (p != null) p.removeView(this);
        if (ouvinte != null) ouvinte.aoFechar(this);
    }

    @Override public boolean dispatchTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) bringToFront();
        return super.dispatchTouchEvent(e);
    }

    private FrameLayout.LayoutParams lp() { return (FrameLayout.LayoutParams) getLayoutParams(); }

    private boolean arrastar(MotionEvent e) {
        View pai = (View) getParent();
        if (pai == null) return false;
        FrameLayout.LayoutParams p = lp();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                ix = e.getRawX(); iy = e.getRawY(); ml = p.leftMargin; mt = p.topMargin;
                return true;
            case MotionEvent.ACTION_MOVE:
                int nl = ml + Math.round(e.getRawX() - ix), nt = mt + Math.round(e.getRawY() - iy);
                p.leftMargin = Math.max(-getWidth() + (int) (60 * d), Math.min(pai.getWidth() - (int) (60 * d), nl));
                p.topMargin = Math.max(0, Math.min(pai.getHeight() - (int) (38 * d), nt));
                setLayoutParams(p);
                return true;
            default:
                return true;
        }
    }

    private boolean redimensionar(MotionEvent e) {
        View pai = (View) getParent();
        if (pai == null) return false;
        FrameLayout.LayoutParams p = lp();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                ix = e.getRawX(); iy = e.getRawY(); w0 = getWidth(); h0 = getHeight();
                return true;
            case MotionEvent.ACTION_MOVE:
                p.width = Math.max(minL, Math.min(pai.getWidth() - p.leftMargin, w0 + Math.round(e.getRawX() - ix)));
                p.height = Math.max(minA, Math.min(pai.getHeight() - p.topMargin, h0 + Math.round(e.getRawY() - iy)));
                setLayoutParams(p);
                return true;
            default:
                return true;
        }
    }
}
