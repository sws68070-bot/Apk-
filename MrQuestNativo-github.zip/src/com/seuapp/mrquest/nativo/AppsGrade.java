package com.seuapp.mrquest.nativo;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Grade com os apps instalados (ícone + nome). Usada na tela cheia (AppsActivity) e na janela flutuante da cena. */
public class AppsGrade extends GridView {
    public interface Ouvinte { void abrir(String pacote, String nome); }

    private static final class Item { String nome, pacote; Drawable icone; }

    private final List<Item> itens = new ArrayList<Item>();
    private final BaseAdapter adapter;
    private final float d;
    private final int corTxt;

    public AppsGrade(final Context ctx, int colunaDp, final Ouvinte ouvinte) {
        super(ctx);
        d = ctx.getResources().getDisplayMetrics().density;
        Estado.init(ctx);
        corTxt = Temas.obter(Estado.s("ui_all", "escuro")).claro ? 0xFF0F172A : 0xFFDDE6FF;
        setNumColumns(AUTO_FIT);
        setColumnWidth((int) (colunaDp * d));
        setVerticalSpacing((int) (8 * d));
        setStretchMode(STRETCH_COLUMN_WIDTH);
        setSelector(new ColorDrawable(0x22FFFFFF));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return itens.size(); }
            @Override public Object getItem(int i) { return itens.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View v, ViewGroup p) {
                LinearLayout c;
                if (v == null) {
                    c = new LinearLayout(ctx);
                    c.setOrientation(LinearLayout.VERTICAL);
                    c.setGravity(Gravity.CENTER_HORIZONTAL);
                    c.setPadding(0, (int) (6 * d), 0, (int) (6 * d));
                    ImageView im = new ImageView(ctx);
                    c.addView(im, new LinearLayout.LayoutParams((int) (48 * d), (int) (48 * d)));
                    TextView t = new TextView(ctx);
                    t.setTextColor(corTxt);
                    t.setTextSize(11);
                    t.setGravity(Gravity.CENTER);
                    t.setMaxLines(2);
                    t.setPadding((int) (4 * d), (int) (4 * d), (int) (4 * d), 0);
                    c.addView(t);
                } else c = (LinearLayout) v;
                Item it = itens.get(i);
                ((ImageView) c.getChildAt(0)).setImageDrawable(it.icone);
                ((TextView) c.getChildAt(1)).setText(it.nome);
                return c;
            }
        };
        setAdapter(adapter);
        setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> a, View v, int i, long id) {
                Item it = itens.get(i);
                if (ouvinte != null) ouvinte.abrir(it.pacote, it.nome);
            }
        });
        carregar(ctx);
    }

    private void carregar(final Context ctx) {
        new Thread(new Runnable() {
            @Override public void run() {
                PackageManager pm = ctx.getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                final List<Item> lista = new ArrayList<Item>();
                for (ResolveInfo r : pm.queryIntentActivities(q, 0)) {
                    if (r.activityInfo.packageName.equals(ctx.getPackageName())) continue;
                    Item it = new Item();
                    it.nome = String.valueOf(r.loadLabel(pm));
                    it.pacote = r.activityInfo.packageName;
                    it.icone = r.loadIcon(pm);
                    lista.add(it);
                }
                Collections.sort(lista, new Comparator<Item>() {
                    @Override public int compare(Item a, Item b) { return a.nome.compareToIgnoreCase(b.nome); }
                });
                post(new Runnable() {
                    @Override public void run() { itens.clear(); itens.addAll(lista); adapter.notifyDataSetChanged(); }
                });
            }
        }).start();
    }
}
