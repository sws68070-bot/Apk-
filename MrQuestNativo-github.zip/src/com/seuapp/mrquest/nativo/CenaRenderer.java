package com.seuapp.mrquest.nativo;

import android.graphics.SurfaceTexture;
import android.graphics.Bitmap;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import android.os.SystemClock;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Cena 3D nativa (OpenGL ES 2.0) guiada pelo 6DOF simulado.
 * Convenção do Pose6Dof: yaw 0 olha para -Z, yaw positivo gira para +X, pitch positivo olha para cima, Y é a altura.
 * Câmera = Rz(-roll) · Rx(-pitch) · Ry(yaw) · T(-pos).
 */
public class CenaRenderer implements GLSurfaceView.Renderer {
    private static final String VS =
            "uniform mat4 uMVP;uniform mat4 uMV;uniform mat4 uR;\n"
          + "attribute vec3 aPos;attribute vec3 aNrm;\n"
          + "varying float vD;varying float vL;\n"
          + "void main(){\n"
          + " gl_Position=uMVP*vec4(aPos,1.0);\n"
          + " vD=length((uMV*vec4(aPos,1.0)).xyz);\n"
          + " vec3 n=normalize((uR*vec4(aNrm,0.0)).xyz);\n"
          + " vL=0.55+0.45*max(dot(n,normalize(vec3(0.4,0.8,0.45))),0.0);\n"
          + "}\n";
    private static final String FS =
            "precision mediump float;\n"
          + "uniform vec4 uCor;uniform vec3 uFog;uniform float uLuz;uniform float uFogOn;\n"
          + "varying float vD;varying float vL;\n"
          + "void main(){\n"
          + " vec3 c=uCor.rgb*mix(1.0,vL,uLuz);\n"
          + " float f=clamp((vD-8.0)/22.0,0.0,1.0)*uFogOn;\n"
          + " gl_FragColor=vec4(mix(c,uFog,f),uCor.a);\n"
          + "}\n";

    // ---- janelas fixas no ambiente (uma View desenhada num Bitmap, mostrada como textura) ----
    private static final String VS_TEX =
            "uniform mat4 uMVP;attribute vec3 aPos;attribute vec2 aUV;varying vec2 vUV;\n"
          + "void main(){gl_Position=uMVP*vec4(aPos,1.0);vUV=aUV;}\n";
    private static final String FS_TEX =
            "precision mediump float;uniform sampler2D uTex;uniform float uA;varying vec2 vUV;\n"
          + "void main(){vec4 c=texture2D(uTex,vUV);gl_FragColor=c*uA;}\n";

    public static final class Fixa {
        public int id;
        public float x, y, z, rotY, w, h;      // posição no mundo (m), giro (graus) e tamanho (m)
        volatile Bitmap pend;
        volatile boolean novo;
        int tex;
    }
    private final java.util.ArrayList<Fixa> fixas = new java.util.ArrayList<Fixa>();
    private int progTex, aPosT, aUVT, uMVPT, uTexT, uAT;
    private FloatBuffer quadT;

    /** Cria uma janela fixa no mundo, de frente para a direção rotY. */
    public void adicionarFixa(int id, float x, float y, float z, float rotY, float w, float h) {
        Fixa f = new Fixa();
        f.id = id; f.x = x; f.y = y; f.z = z; f.rotY = rotY; f.w = w; f.h = h;
        synchronized (fixas) { fixas.add(f); }
    }

    public void moverFixa(int id, float x, float y, float z, float rotY) {
        synchronized (fixas) {
            for (Fixa f : fixas) if (f.id == id) { f.x = x; f.y = y; f.z = z; f.rotY = rotY; return; }
        }
    }

    public void removerFixa(int id) {
        synchronized (fixas) {
            for (int i = 0; i < fixas.size(); i++) if (fixas.get(i).id == id) { fixas.remove(i); return; }
        }
    }

    /** Novo desenho da janela (thread da interface). A altura é fixa; a largura segue a proporção. */
    public void enviarQuadro(int id, Bitmap b, float aspecto) {
        synchronized (fixas) {
            for (Fixa f : fixas) if (f.id == id) { f.w = f.h * aspecto; f.pend = b; f.novo = true; return; }
        }
    }

    /** Raio da tela (-1..1) contra as janelas fixas: devolve {id, u, v} (u e v de 0 a 1 na janela) ou null. */
    public float[] acertoFixa(float nx, float ny) {
        float[] inv = new float[16];
        synchronized (trava) { if (!temVp) return null; System.arraycopy(vpInv, 0, inv, 0, 16); }
        float[] a = {nx, ny, -1, 1}, b = {nx, ny, 1, 1}, pa = new float[4], pb = new float[4];
        Matrix.multiplyMV(pa, 0, inv, 0, a, 0);
        Matrix.multiplyMV(pb, 0, inv, 0, b, 0);
        for (int k = 0; k < 3; k++) { pa[k] /= pa[3]; pb[k] /= pb[3]; }
        float dx = pb[0] - pa[0], dy = pb[1] - pa[1], dz = pb[2] - pa[2];
        float[] melhor = null;
        float tMelhor = 1e9f;
        synchronized (fixas) {
            for (Fixa f : fixas) {
                double r = Math.toRadians(f.rotY);
                float sn = (float) Math.sin(r), cs = (float) Math.cos(r);
                float den = dx * sn + dz * cs;
                if (Math.abs(den) < 1e-6f) continue;
                float t = ((f.x - pa[0]) * sn + (f.z - pa[2]) * cs) / den;
                if (t < 0 || t > tMelhor) continue;
                float hx = pa[0] + dx * t, hy = pa[1] + dy * t, hz = pa[2] + dz * t;
                float lx = (hx - f.x) * cs - (hz - f.z) * sn, ly = hy - f.y;
                float u = lx / f.w + .5f, v = .5f - ly / f.h;
                if (u >= 0 && u <= 1 && v >= 0 && v <= 1) { tMelhor = t; melhor = new float[]{f.id, u, v}; }
            }
        }
        return melhor;
    }

    private void desenharFixas() {
        synchronized (fixas) {
            if (fixas.isEmpty()) return;
            GLES20.glUseProgram(progTex);
            GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA);   // o Bitmap vem com alfa pré-multiplicado
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            for (Fixa f : fixas) {
                if (f.tex == 0) {
                    int[] t = new int[1];
                    GLES20.glGenTextures(1, t, 0);
                    f.tex = t[0];
                    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, f.tex);
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
                }
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, f.tex);
                Bitmap b = f.pend;
                if (f.novo && b != null && !b.isRecycled()) {
                    f.novo = false;
                    GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0);
                } else if (b == null) continue;   // ainda sem imagem
                Matrix.setIdentityM(M, 0);
                Matrix.translateM(M, 0, f.x, f.y, f.z);
                Matrix.rotateM(M, 0, f.rotY, 0, 1, 0);
                Matrix.scaleM(M, 0, f.w, f.h, 1f);
                Matrix.multiplyMM(MV, 0, Vat, 0, M, 0);
                Matrix.multiplyMM(MVP, 0, P, 0, MV, 0);
                GLES20.glUniformMatrix4fv(uMVPT, 1, false, MVP, 0);
                GLES20.glUniform1i(uTexT, 0);
                GLES20.glUniform1f(uAT, Math.max(.4f, opJan));
                quadT.position(0);
                GLES20.glVertexAttribPointer(aPosT, 3, GLES20.GL_FLOAT, false, 20, quadT);
                GLES20.glEnableVertexAttribArray(aPosT);
                quadT.position(3);
                GLES20.glVertexAttribPointer(aUVT, 2, GLES20.GL_FLOAT, false, 20, quadT);
                GLES20.glEnableVertexAttribArray(aUVT);
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
            }
            GLES20.glDisableVertexAttribArray(aPosT);
            GLES20.glDisableVertexAttribArray(aUVT);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
            GLES20.glUseProgram(prog);
        }
    }

    // ---- céu por imagem panorâmica (equiretangular) ----
    private static final String FS_IMG =
            "precision mediump float;uniform sampler2D uTex;varying vec3 vD;\n"
          + "void main(){vec3 d=normalize(vD);\n"
          + " vec2 uv=vec2(atan(d.z,d.x)/6.2831853+0.5,0.5-asin(clamp(d.y,-1.0,1.0))/3.14159265);\n"
          + " gl_FragColor=vec4(texture2D(uTex,uv).rgb,1.0);}\n";
    public volatile Bitmap imgCeu;
    private volatile boolean imgNovo;
    private int progImg, aPosI, uVPI, uTexI, texImg;

    public void definirImagem(Bitmap b) { imgCeu = b; imgNovo = b != null; }

    private void desenharCeuImg() {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glUseProgram(progImg);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        if (texImg == 0) {
            int[] t = new int[1];
            GLES20.glGenTextures(1, t, 0);
            texImg = t[0];
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texImg);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            imgNovo = imgCeu != null;
        }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texImg);
        Bitmap b = imgCeu;
        if (imgNovo && b != null && !b.isRecycled()) { imgNovo = false; GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0); }
        GLES20.glUniformMatrix4fv(uVPI, 1, false, VPc, 0);
        GLES20.glUniform1i(uTexI, 0);
        GLES20.glEnableVertexAttribArray(aPosI);
        ceuB.position(0);
        GLES20.glVertexAttribPointer(aPosI, 3, GLES20.GL_FLOAT, false, 12, ceuB);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, nCeu);
        GLES20.glDisableVertexAttribArray(aPosI);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, 0);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glUseProgram(prog);
    }

    // ---- céu (degradê por direção) e estrelas ----
    private static final String VS_CEU =
            "uniform mat4 uVP;attribute vec3 aPos;varying vec3 vD;\n"
          + "void main(){gl_Position=uVP*vec4(aPos,1.0);vD=aPos;gl_PointSize=2.5;}\n";
    private static final String FS_CEU =
            "precision mediump float;\n"
          + "uniform float uT[6];uniform vec3 uC[6];uniform float uStar;varying vec3 vD;\n"
          + "void main(){\n"
          + " if(uStar>0.5){gl_FragColor=vec4(1.0,1.0,1.0,0.9);return;}\n"
          + " float t=0.5-asin(clamp(normalize(vD).y,-1.0,1.0))/3.14159265;\n"
          + " vec3 c=uC[0];\n"
          + " for(int i=0;i<5;i++){if(t>=uT[i]){float k=clamp((t-uT[i])/max(uT[i+1]-uT[i],0.0001),0.0,1.0);c=mix(uC[i],uC[i+1],k);}}\n"
          + " gl_FragColor=vec4(c,1.0);\n"
          + "}\n";

    // ---- passthrough (câmera como textura externa) ----
    public interface Ouvinte { void texturaPronta(SurfaceTexture st); }
    private static final String VS_CAM =
            "attribute vec2 aPC;attribute vec2 aTC;uniform mat4 uST;varying vec2 vT;\n"
          + "void main(){gl_Position=vec4(aPC,0.999,1.0);vT=(uST*vec4(aTC,0.0,1.0)).xy;}\n";
    private static final String FS_CAM =
            "#extension GL_OES_EGL_image_external : require\n"
          + "precision mediump float;uniform samplerExternalOES uTex;varying vec2 vT;\n"
          + "void main(){gl_FragColor=texture2D(uTex,vT);}\n";
    public static volatile String camEstado = "cena fechada";
    public static volatile String maoEstado = "desligada";
    public volatile boolean camAtiva;      // a Activity liga quando a câmera abriu
    public volatile int camRot;            // graus: sensor - rotação da tela
    public volatile float camAsp = 4f / 3f;
    public Ouvinte ouvinte;
    private SurfaceTexture stCam;
    private volatile boolean quadroNovo;
    private boolean temQuadro, fundoCam;
    private int progCam, uST, uTexCam, aPC, aTC, uFogOn;
    private final int[] texCam = new int[1];
    private final float[] stM = new float[16], qv = new float[16];
    private FloatBuffer qBuf;

    private static final float[] FUNDO = {10f / 255f, 12f / 255f, 18f / 255f};   // #0a0c12 (mesmo fundo da tela inicial)
    private static final float IPD = 0.064f;                                      // distância entre os olhos (modo VR)
    private static final float FOV = 80f;                                         // mesmo fov do original

    /** Medição de desempenho (lida pelo painel Desenvolvedor e pelo texto da cena). */
    public static volatile float fps, ms, pior;
    public volatile int limite = 30;       // fps máximo (0 = livre) — Configurações > Desempenho
    public volatile String cenario = "padrao";   // chave de Cenarios (Configurações > Visão)
    public volatile Temas.T temaJan = Temas.obter("escuro"), temaDock = Temas.obter("escuro");   // Configurações > Interface
    public volatile float opJan = 1f, dockEsc = 1f;     // transparência das janelas, tamanho da barra de baixo
    public volatile boolean brilho;
    public volatile boolean semExemplo;                 // some com as 2 janelas de exemplo quando há janelas reais fixadas                     // brilho de destaque (dourado)
    public volatile boolean leve;          // Modo desempenho: menos linhas de grade e menos colunas
    private long tFrame;
    private long tIni, tUlt;
    private int nQ;
    private float piorJ;

    private final Pose6Dof pose;
    private final boolean estereo;

    private Cenarios.Cen cen = Cenarios.obter("padrao");
    private String cenAplicado = "padrao";
    private int progCeu, aPosCeu, uVPCeu, uTCeu, uCCeu, uStarCeu, nCeu, nEstrelas;
    private FloatBuffer ceuB, estrelasB;
    private final float[] VPc = new float[16], Vc = new float[16];
    private int prog, aPos, aNrm, uMVP, uMV, uR, uCor, uFog, uLuz;
    private FloatBuffer cubo, discoB, gradeMenor, gradeMaior;
    private int nDisco, nMenor, nMaior;
    private final float[] P = new float[16], V = new float[16], VE = new float[16], TE = new float[16];
    private final float[] M = new float[16], MV = new float[16], MVP = new float[16], R = new float[16];
    private float[] Vat = V;
    private int W = 1, H = 1;

    // ---- toque nos ícones do dock ----
    private static final float DOCK_X = 0f, DOCK_Y = 1.05f, DOCK_Z = -1.675f, DOCK_PASSO = 0.34f, ALVO = 0.12f;
    private final Object trava = new Object();
    private final float[] vpInv = new float[16];
    private boolean temVp;
    private volatile int destaque = -1;
    private volatile long destaqueAte;

    private void guardarRaio() {
        float[] vp = new float[16], inv = new float[16];
        Matrix.multiplyMM(vp, 0, P, 0, V, 0);
        if (Matrix.invertM(inv, 0, vp, 0)) synchronized (trava) { System.arraycopy(inv, 0, vpInv, 0, 16); temVp = true; }
    }

    /** Raio da tela (nx, ny em -1..1) contra o plano do dock. Devolve o ícone tocado (0..2) ou -1. Pode ser chamado fora da thread GL. */
    public int acerto(float nx, float ny) {
        float[] inv = new float[16];
        synchronized (trava) { if (!temVp) return -1; System.arraycopy(vpInv, 0, inv, 0, 16); }
        float[] a = {nx, ny, -1, 1}, b = {nx, ny, 1, 1}, pa = new float[4], pb = new float[4];
        Matrix.multiplyMV(pa, 0, inv, 0, a, 0);
        Matrix.multiplyMV(pb, 0, inv, 0, b, 0);
        for (int k = 0; k < 3; k++) { pa[k] /= pa[3]; pb[k] /= pb[3]; }
        float dz = pb[2] - pa[2];
        if (Math.abs(dz) < 1e-6f) return -1;
        float t = (DOCK_Z - pa[2]) / dz;
        if (t < 0) return -1;
        float hx = pa[0] + (pb[0] - pa[0]) * t, hy = pa[1] + (pb[1] - pa[1]) * t;
        for (int i = 0; i < 3; i++) {
            float dx = hx - (DOCK_X + (i - 1) * DOCK_PASSO * dockEsc), dy = hy - DOCK_Y;
            float al = ALVO * dockEsc;
            if (dx * dx + dy * dy < al * al) { destaque = i; destaqueAte = SystemClock.uptimeMillis() + 220; return i; }
        }
        return -1;
    }

    public CenaRenderer(Pose6Dof pose, boolean estereo) {
        this.pose = pose;
        this.estereo = estereo;
    }

    // ================= GL =================
    @Override public void onSurfaceCreated(GL10 gl, EGLConfig cfg) {
        int vs = shader(GLES20.GL_VERTEX_SHADER, VS), fs = shader(GLES20.GL_FRAGMENT_SHADER, FS);
        prog = GLES20.glCreateProgram();
        GLES20.glAttachShader(prog, vs);
        GLES20.glAttachShader(prog, fs);
        GLES20.glLinkProgram(prog);
        aPos = GLES20.glGetAttribLocation(prog, "aPos");
        aNrm = GLES20.glGetAttribLocation(prog, "aNrm");
        uMVP = GLES20.glGetUniformLocation(prog, "uMVP");
        uMV = GLES20.glGetUniformLocation(prog, "uMV");
        uR = GLES20.glGetUniformLocation(prog, "uR");
        uCor = GLES20.glGetUniformLocation(prog, "uCor");
        uFog = GLES20.glGetUniformLocation(prog, "uFog");
        uLuz = GLES20.glGetUniformLocation(prog, "uLuz");
        montarMalhas();
        progCeu = GLES20.glCreateProgram();
        GLES20.glAttachShader(progCeu, shader(GLES20.GL_VERTEX_SHADER, VS_CEU));
        GLES20.glAttachShader(progCeu, shader(GLES20.GL_FRAGMENT_SHADER, FS_CEU));
        GLES20.glLinkProgram(progCeu);
        aPosCeu = GLES20.glGetAttribLocation(progCeu, "aPos");
        uVPCeu = GLES20.glGetUniformLocation(progCeu, "uVP");
        uTCeu = GLES20.glGetUniformLocation(progCeu, "uT");
        if (uTCeu < 0) uTCeu = GLES20.glGetUniformLocation(progCeu, "uT[0]");
        uCCeu = GLES20.glGetUniformLocation(progCeu, "uC");
        if (uCCeu < 0) uCCeu = GLES20.glGetUniformLocation(progCeu, "uC[0]");
        uStarCeu = GLES20.glGetUniformLocation(progCeu, "uStar");
        montarCeu();
        progImg = GLES20.glCreateProgram();
        GLES20.glAttachShader(progImg, shader(GLES20.GL_VERTEX_SHADER, VS_CEU));
        GLES20.glAttachShader(progImg, shader(GLES20.GL_FRAGMENT_SHADER, FS_IMG));
        GLES20.glLinkProgram(progImg);
        aPosI = GLES20.glGetAttribLocation(progImg, "aPos");
        uVPI = GLES20.glGetUniformLocation(progImg, "uVP");
        uTexI = GLES20.glGetUniformLocation(progImg, "uTex");
        texImg = 0;
        progTex = GLES20.glCreateProgram();
        GLES20.glAttachShader(progTex, shader(GLES20.GL_VERTEX_SHADER, VS_TEX));
        GLES20.glAttachShader(progTex, shader(GLES20.GL_FRAGMENT_SHADER, FS_TEX));
        GLES20.glLinkProgram(progTex);
        aPosT = GLES20.glGetAttribLocation(progTex, "aPos");
        aUVT = GLES20.glGetAttribLocation(progTex, "aUV");
        uMVPT = GLES20.glGetUniformLocation(progTex, "uMVP");
        uTexT = GLES20.glGetUniformLocation(progTex, "uTex");
        uAT = GLES20.glGetUniformLocation(progTex, "uA");
        quadT = buf(new float[]{
                -.5f, .5f, 0, 0, 0,   -.5f, -.5f, 0, 0, 1,   .5f, -.5f, 0, 1, 1,
                -.5f, .5f, 0, 0, 0,    .5f, -.5f, 0, 1, 1,   .5f,  .5f, 0, 1, 0});
        synchronized (fixas) { for (Fixa f : fixas) { f.tex = 0; f.novo = f.pend != null; } }   // o contexto GL antigo se foi
        uFogOn = GLES20.glGetUniformLocation(prog, "uFogOn");
        // passthrough: textura externa + SurfaceTexture que a Camera2 preenche
        progCam = GLES20.glCreateProgram();
        GLES20.glAttachShader(progCam, shader(GLES20.GL_VERTEX_SHADER, VS_CAM));
        GLES20.glAttachShader(progCam, shader(GLES20.GL_FRAGMENT_SHADER, FS_CAM));
        GLES20.glLinkProgram(progCam);
        aPC = GLES20.glGetAttribLocation(progCam, "aPC");
        aTC = GLES20.glGetAttribLocation(progCam, "aTC");
        uST = GLES20.glGetUniformLocation(progCam, "uST");
        uTexCam = GLES20.glGetUniformLocation(progCam, "uTex");
        qBuf = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        GLES20.glGenTextures(1, texCam, 0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texCam[0]);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        stCam = new SurfaceTexture(texCam[0]);
        temQuadro = false;
        stCam.setOnFrameAvailableListener(new SurfaceTexture.OnFrameAvailableListener() {
            @Override public void onFrameAvailable(SurfaceTexture s) { quadroNovo = true; }
        });
        if (ouvinte != null) ouvinte.texturaPronta(stCam);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
    }

    public static void zerarMedicao() { fps = 0; ms = 0; pior = 0; }

    @Override public void onSurfaceChanged(GL10 gl, int w, int h) {
        W = Math.max(1, w);
        H = Math.max(1, h);
    }

    @Override public void onDrawFrame(GL10 gl) {
        if (limite > 0) {   // limite de quadros: dorme o que sobrar do tempo do quadro (poupa CPU, GPU e bateria)
            long alvo = 1000L / limite, ja = SystemClock.uptimeMillis() - tFrame;
            if (ja < alvo) { try { Thread.sleep(alvo - ja); } catch (InterruptedException e) { } }
        }
        tFrame = SystemClock.uptimeMillis();
        long ag = SystemClock.uptimeMillis();
        if (tUlt != 0) piorJ = Math.max(piorJ, ag - tUlt);
        tUlt = ag;
        if (tIni == 0) tIni = ag;
        nQ++;
        if (ag - tIni >= 1000) { fps = nQ * 1000f / (ag - tIni); ms = (ag - tIni) / (float) nQ; pior = piorJ; nQ = 0; piorJ = 0; tIni = ag; }
        GLES20.glClearColor(FUNDO[0], FUNDO[1], FUNDO[2], 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        // quadro novo da câmera → textura
        if (camAtiva && stCam != null && quadroNovo) {
            quadroNovo = false;
            try { stCam.updateTexImage(); stCam.getTransformMatrix(stM); temQuadro = true; } catch (Exception e) { }
        }
        fundoCam = camAtiva && temQuadro;
        String cn = cenario;
        if (cn != null && !cn.equals(cenAplicado)) { cen = Cenarios.obter(cn); cenAplicado = cn; }
        float[] hz = cen.horizonte();
        GLES20.glUseProgram(prog);
        GLES20.glUniform3f(uFog, hz[0], hz[1], hz[2]);
        GLES20.glUniform1f(uFogOn, fundoCam ? 0f : 1f);

        // câmera a partir do 6DOF
        Matrix.setIdentityM(V, 0);
        Matrix.rotateM(V, 0, (float) Math.toDegrees(-pose.roll), 0, 0, 1);
        Matrix.rotateM(V, 0, (float) Math.toDegrees(-pose.pitch), 1, 0, 0);
        Matrix.rotateM(V, 0, (float) Math.toDegrees(pose.yaw), 0, 1, 0);
        Matrix.translateM(V, 0, -pose.x, -pose.y, -pose.z);

        if (!estereo) {
            GLES20.glViewport(0, 0, W, H);
            Matrix.perspectiveM(P, 0, FOV, (float) W / H, 0.05f, 80f);
            guardarRaio();
            if (fundoCam) desenharCam((float) W / H); else desenharCeu(V);
            Vat = V;
            cena();
        } else {
            int mw = W / 2;
            Matrix.perspectiveM(P, 0, FOV, (float) mw / H, 0.05f, 80f);
            guardarRaio();
            for (int olho = 0; olho < 2; olho++) {
                GLES20.glViewport(olho * mw, 0, mw, H);
                GLES20.glScissor(olho * mw, 0, mw, H);
                GLES20.glEnable(GLES20.GL_SCISSOR_TEST);
                Matrix.setIdentityM(TE, 0);
                Matrix.translateM(TE, 0, olho == 0 ? IPD / 2 : -IPD / 2, 0, 0);
                Matrix.multiplyMM(VE, 0, TE, 0, V, 0);
                Vat = VE;
                if (fundoCam) desenharCam((float) mw / H); else desenharCeu(VE);
                cena();
                GLES20.glDisable(GLES20.GL_SCISSOR_TEST);
            }
        }
    }

    /** Céu: esfera em volta do olhar (sem translação), degradê calculado por direção + estrelas no alto. */
    private void desenharCeu(float[] vista) {
        System.arraycopy(vista, 0, Vc, 0, 16);
        Vc[12] = 0; Vc[13] = 0; Vc[14] = 0;
        Matrix.multiplyMM(VPc, 0, P, 0, Vc, 0);
        if ("imagem".equals(cenAplicado) && imgCeu != null && progImg != 0) { desenharCeuImg(); return; }
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glUseProgram(progCeu);
        GLES20.glUniformMatrix4fv(uVPCeu, 1, false, VPc, 0);
        GLES20.glUniform1fv(uTCeu, 6, cen.t, 0);
        GLES20.glUniform3fv(uCCeu, 6, cen.c, 0);
        GLES20.glEnableVertexAttribArray(aPosCeu);
        GLES20.glUniform1f(uStarCeu, 0f);
        ceuB.position(0);
        GLES20.glVertexAttribPointer(aPosCeu, 3, GLES20.GL_FLOAT, false, 12, ceuB);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, nCeu);
        if (!leve) {
            GLES20.glUniform1f(uStarCeu, 1f);
            estrelasB.position(0);
            GLES20.glVertexAttribPointer(aPosCeu, 3, GLES20.GL_FLOAT, false, 12, estrelasB);
            GLES20.glDrawArrays(GLES20.GL_POINTS, 0, nEstrelas);
        }
        GLES20.glDisableVertexAttribArray(aPosCeu);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glUseProgram(prog);
    }

    private void montarCeu() {
        int fat = 16, sl = 32;   // 16 faixas de latitude × 32 de longitude
        float[] v = new float[fat * sl * 6 * 3];
        int k = 0;
        for (int i = 0; i < fat; i++) {
            for (int j = 0; j < sl; j++) {
                float[][] q = {pontoEsf(i, j, fat, sl), pontoEsf(i + 1, j, fat, sl), pontoEsf(i + 1, j + 1, fat, sl), pontoEsf(i, j + 1, fat, sl)};
                int[] ord = {0, 1, 2, 0, 2, 3};
                for (int o : ord) { v[k++] = q[o][0]; v[k++] = q[o][1]; v[k++] = q[o][2]; }
            }
        }
        ceuB = buf(v);
        nCeu = fat * sl * 6;
        nEstrelas = 500;
        float[] e = new float[nEstrelas * 3];
        java.util.Random rnd = new java.util.Random(7);
        for (int i = 0; i < nEstrelas; i++) {
            double a = rnd.nextDouble() * 6.28, b = rnd.nextDouble() * 1.2 + .1;   // mesma distribuição do original
            e[i * 3] = (float) (Math.cos(a) * Math.cos(b));
            e[i * 3 + 1] = (float) Math.sin(b);
            e[i * 3 + 2] = (float) (Math.sin(a) * Math.cos(b));
        }
        estrelasB = buf(e);
    }

    private static float[] pontoEsf(int i, int j, int fat, int sl) {
        double lat = Math.PI / 2 - Math.PI * i / fat, lon = 2 * Math.PI * j / sl;
        return new float[]{(float) (Math.cos(lat) * Math.cos(lon)), (float) Math.sin(lat), (float) (Math.cos(lat) * Math.sin(lon))};
    }

    /** Desenha o quadro da câmera cobrindo a tela inteira (recorta o excesso, sem esticar). */
    private void desenharCam(float A) {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glUseProgram(progCam);
        int rot = camRot;
        float c = camAsp, eff = (rot % 180 != 0) ? 1f / c : c;
        float sx = Math.min(1f, A / eff), sy = Math.min(1f, eff / A);
        double th = Math.toRadians(rot);
        float ct = (float) Math.cos(th), sn = (float) Math.sin(th);
        float[][] pos = {{-1, -1}, {1, -1}, {-1, 1}, {1, 1}};
        for (int i = 0; i < 4; i++) {
            float dx = pos[i][0] * .5f * sx, dy = pos[i][1] * .5f * sy;
            qv[i * 4] = pos[i][0];
            qv[i * 4 + 1] = pos[i][1];
            qv[i * 4 + 2] = dx * ct - dy * sn + .5f;
            qv[i * 4 + 3] = dx * sn + dy * ct + .5f;
        }
        qBuf.position(0);
        qBuf.put(qv).position(0);
        GLES20.glUniformMatrix4fv(uST, 1, false, stM, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texCam[0]);
        GLES20.glUniform1i(uTexCam, 0);
        qBuf.position(0);
        GLES20.glVertexAttribPointer(aPC, 2, GLES20.GL_FLOAT, false, 16, qBuf);
        GLES20.glEnableVertexAttribArray(aPC);
        qBuf.position(2);
        GLES20.glVertexAttribPointer(aTC, 2, GLES20.GL_FLOAT, false, 16, qBuf);
        GLES20.glEnableVertexAttribArray(aTC);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glDisableVertexAttribArray(aPC);
        GLES20.glDisableVertexAttribArray(aTC);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glUseProgram(prog);
    }

    // ================= cena =================
    private void cena() {
        // chão escuro + grade
        if (!fundoCam) caixa(0, -0.01f, 0, 80, 0.02f, 80, 0, cen.chao[0], cen.chao[1], cen.chao[2], 1f, true);   // com passthrough o chão é o ambiente real
        if (!leve) linhas(gradeMenor, nMenor, cen.gMenor[0], cen.gMenor[1], cen.gMenor[2], .8f);
        linhas(gradeMaior, nMaior, cen.gMaior[0], cen.gMaior[1], cen.gMaior[2], .8f);

        // seta "frente inicial" no chão
        caixa(0, 0.004f, -2.2f, 0.10f, 0.008f, 1.2f, 0, .36f, .55f, 1f, 1f, false);
        caixa(-0.14f, 0.004f, -2.75f, 0.10f, 0.008f, 0.45f, -35, .36f, .55f, 1f, 1f, false);
        caixa(0.14f, 0.004f, -2.75f, 0.10f, 0.008f, 0.45f, 35, .36f, .55f, 1f, 1f, false);

        // anel de colunas (dá parallax e noção de escala)
        float[][] cor = {{.36f, .55f, 1f}, {1f, .60f, .12f}, {.35f, .85f, .55f}, {.85f, .40f, .75f}};
        for (int i = 0; i < 12; i += leve ? 2 : 1) {
            double a = i * Math.PI / 6;
            float x = (float) Math.sin(a) * 7f, z = (float) -Math.cos(a) * 7f;
            float alt = 1.2f + (i % 4) * 0.9f;
            float[] c = cor[i % 4];
            caixa(x, alt / 2, z, 0.5f, alt, 0.5f, (float) Math.toDegrees(-a), c[0], c[1], c[2], 1f, true);
        }
        // plataforma central baixa e dois blocos de referência
        caixa(0, 0.05f, 0, 1.6f, 0.1f, 1.6f, 0, .20f, .24f, .36f, 1f, true);
        caixa(-3f, 0.25f, -3f, 0.5f, 0.5f, 0.5f, 25, 1f, .60f, .12f, 1f, true);
        caixa(3f, 0.4f, -4f, 0.8f, 0.8f, 0.8f, -15, .35f, .85f, .55f, 1f, true);

        // translúcidos por último: dock e janelas
        GLES20.glDepthMask(false);
        desenharFixas();
        dock(0f, 1.05f, -1.7f, 0);
        if (!semExemplo) {
            janela(-2.3f, 1.45f, -2.4f, 28);
            janela(2.3f, 1.45f, -2.4f, -28);
        }
        GLES20.glDepthMask(true);
    }

    private void dock(float x, float y, float z, float rotY) {
        float e = dockEsc;
        float[] k = temaDock.dk3;
        if (brilho) caixa(x, y, z - 0.012f, 1.34f * e, 0.28f * e, 0.01f, rotY, 1f, .78f, .20f, .55f, false);
        caixa(x, y, z, 1.30f * e, 0.24f * e, 0.04f, rotY, k[0], k[1], k[2], .90f, false);
        float[][] ic = {{.36f, .55f, 1f}, {1f, .60f, .12f}, {.62f, .66f, .78f}};
        long ag = SystemClock.uptimeMillis();
        for (int i = 0; i < 3; i++) disco(x + (i - 1) * DOCK_PASSO * e, y, z + 0.025f, ((destaque == i && ag < destaqueAte) ? 0.11f : 0.085f) * e, ic[i][0], ic[i][1], ic[i][2]);
    }

    private void janela(float x, float y, float z, float rotY) {
        Temas.T t = temaJan;
        float op = opJan;
        float[] f = brilho ? new float[]{1f, .78f, .20f} : t.fr3;
        caixa(x, y, z - 0.012f, 1.46f, 0.96f, 0.01f, rotY, f[0], f[1], f[2], brilho ? .75f : .9f * op, false);   // borda
        caixa(x, y, z, 1.40f, 0.90f, 0.02f, rotY, t.bg3[0], t.bg3[1], t.bg3[2], .90f * op, false);              // vidro
        caixa(x, y + 0.40f, z + 0.015f, 1.40f, 0.10f, 0.012f, rotY, t.bar3[0], t.bar3[1], t.bar3[2], .96f * op, false);   // barra de título
    }

    // ================= desenho =================
    private void preparar(float rotY) {
        Matrix.multiplyMM(MV, 0, Vat, 0, M, 0);
        Matrix.multiplyMM(MVP, 0, P, 0, MV, 0);
        Matrix.setRotateM(R, 0, rotY, 0, 1, 0);
        GLES20.glUniformMatrix4fv(uMVP, 1, false, MVP, 0);
        GLES20.glUniformMatrix4fv(uMV, 1, false, MV, 0);
        GLES20.glUniformMatrix4fv(uR, 1, false, R, 0);
    }

    private void ligarBuf(FloatBuffer b) {
        b.position(0);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, b);
        GLES20.glEnableVertexAttribArray(aPos);
        b.position(3);
        GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, 24, b);
        GLES20.glEnableVertexAttribArray(aNrm);
    }

    private void caixa(float x, float y, float z, float sx, float sy, float sz, float rotY,
                       float r, float g, float b, float a, boolean luz) {
        Matrix.setIdentityM(M, 0);
        Matrix.translateM(M, 0, x, y, z);
        Matrix.rotateM(M, 0, rotY, 0, 1, 0);
        Matrix.scaleM(M, 0, sx, sy, sz);
        preparar(rotY);
        GLES20.glUniform4f(uCor, r, g, b, a);
        GLES20.glUniform1f(uLuz, luz ? 1f : 0f);
        ligarBuf(cubo);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36);
    }

    private void disco(float x, float y, float z, float raio, float r, float g, float b) {
        Matrix.setIdentityM(M, 0);
        Matrix.translateM(M, 0, x, y, z);
        Matrix.scaleM(M, 0, raio, raio, 1f);
        preparar(0);
        GLES20.glUniform4f(uCor, r, g, b, 1f);
        GLES20.glUniform1f(uLuz, 0f);
        ligarBuf(discoB);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, nDisco);
    }

    private void linhas(FloatBuffer buf, int n, float r, float g, float b, float a) {
        Matrix.setIdentityM(M, 0);
        preparar(0);
        GLES20.glUniform4f(uCor, r, g, b, a);
        GLES20.glUniform1f(uLuz, 0f);
        ligarBuf(buf);
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, n);
    }

    // ================= malhas =================
    private void montarMalhas() {
        // cubo unitário centrado (±0,5), 6 faces com normais; formato: x y z nx ny nz
        float[][] f = {   // normal + 2 eixos do plano
                {0, 0, 1, 1, 0, 0, 0, 1, 0}, {0, 0, -1, -1, 0, 0, 0, 1, 0},
                {1, 0, 0, 0, 0, -1, 0, 1, 0}, {-1, 0, 0, 0, 0, 1, 0, 1, 0},
                {0, 1, 0, 1, 0, 0, 0, 0, -1}, {0, -1, 0, 1, 0, 0, 0, 0, 1}};
        float[] c = new float[36 * 6];
        int k = 0;
        for (float[] q : f) {
            float nx = q[0], ny = q[1], nz = q[2];
            float ux = q[3], uy = q[4], uz = q[5], vx = q[6], vy = q[7], vz = q[8];
            int[][] ord = {{-1, -1}, {1, -1}, {1, 1}, {-1, -1}, {1, 1}, {-1, 1}};
            for (int[] o : ord) {
                c[k++] = nx * .5f + ux * o[0] * .5f + vx * o[1] * .5f;
                c[k++] = ny * .5f + uy * o[0] * .5f + vy * o[1] * .5f;
                c[k++] = nz * .5f + uz * o[0] * .5f + vz * o[1] * .5f;
                c[k++] = nx; c[k++] = ny; c[k++] = nz;
            }
        }
        cubo = buf(c);

        nDisco = 34;
        float[] d = new float[nDisco * 6];
        d[5] = 1;
        for (int i = 0; i <= 32; i++) {
            double a = i * 2 * Math.PI / 32;
            int o = (i + 1) * 6;
            d[o] = (float) Math.cos(a); d[o + 1] = (float) Math.sin(a); d[o + 5] = 1;
        }
        discoB = buf(d);

        // grade 40 x 40 m, linhas finas a cada 1 m e destacadas a cada 5 m
        int mn = 0, mj = 0;
        float[] a1 = new float[41 * 4 * 6], a2 = new float[9 * 4 * 6];
        for (int i = -20; i <= 20; i++) {
            float[] alvo = (i % 5 == 0) ? a2 : a1;
            int idx = (i % 5 == 0) ? mj : mn;
            float[] l = {i, 0.002f, -20, 0, 1, 0, i, 0.002f, 20, 0, 1, 0, -20, 0.002f, i, 0, 1, 0, 20, 0.002f, i, 0, 1, 0};
            System.arraycopy(l, 0, alvo, idx, l.length);
            if (i % 5 == 0) mj += l.length; else mn += l.length;
        }
        gradeMenor = buf(java.util.Arrays.copyOf(a1, mn));
        gradeMaior = buf(java.util.Arrays.copyOf(a2, mj));
        nMenor = mn / 6;
        nMaior = mj / 6;
    }

    private static FloatBuffer buf(float[] v) {
        FloatBuffer b = ByteBuffer.allocateDirect(v.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        b.put(v).position(0);
        return b;
    }

    private static int shader(int tipo, String src) {
        int s = GLES20.glCreateShader(tipo);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        return s;
    }
}
