package com.seuapp.mrquest.nativo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Esqueleto da mão por cima da cena (21 pontos) + cursor na ponta do indicador. Não recebe toques. */
public class MaoOverlay extends View {
    private static final int[][] LIG = {{0,1},{1,2},{2,3},{3,4},{0,5},{5,6},{6,7},{7,8},{5,9},{9,10},{10,11},{11,12},
            {9,13},{13,14},{14,15},{15,16},{13,17},{17,18},{18,19},{19,20},{0,17}};
    private final Paint linha = new Paint(Paint.ANTI_ALIAS_FLAG), ponto = new Paint(Paint.ANTI_ALIAS_FLAG), cursor = new Paint(Paint.ANTI_ALIAS_FLAG);
    private volatile float[] nx, ny;     // coordenadas de tela normalizadas (-1..1)
    private volatile boolean pinca;
    private final float d;

    public MaoOverlay(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        linha.setStrokeWidth(2.5f * d);
        linha.setColor(0xCC5B8CFF);
        ponto.setColor(0xFFFFFFFF);
        cursor.setStyle(Paint.Style.STROKE);
        cursor.setStrokeWidth(3f * d);
        setClickable(false);
    }

    public void definir(float[] x, float[] y, boolean pinca) {
        nx = x; ny = y; this.pinca = pinca;
        postInvalidate();
    }

    @Override protected void onDraw(Canvas c) {
        float[] x = nx, y = ny;
        if (x == null || y == null || !Estado.b("ui_skel", true)) return;
        int W = getWidth(), H = getHeight();
        for (int[] l : LIG) c.drawLine((x[l[0]] + 1) / 2 * W, (1 - y[l[0]]) / 2 * H, (x[l[1]] + 1) / 2 * W, (1 - y[l[1]]) / 2 * H, linha);
        for (int i = 0; i < x.length; i++) c.drawCircle((x[i] + 1) / 2 * W, (1 - y[i]) / 2 * H, 3.5f * d, ponto);
        cursor.setColor(pinca ? 0xFF35E08A : 0xFFFFFFFF);
        c.drawCircle((x[8] + 1) / 2 * W, (1 - y[8]) / 2 * H, (pinca ? 14 : 18) * d, cursor);
    }
}
