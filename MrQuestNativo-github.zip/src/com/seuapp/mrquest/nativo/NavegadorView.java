package com.seuapp.mrquest.nativo;

import android.content.Context;
import android.graphics.Color;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Mini navegador para a janela flutuante: barra de endereço, voltar e página (apps/plugins HTML também abrem aqui). */
public class NavegadorView extends LinearLayout {
    private final WebView web;
    private final EditText url;
    /** Chamado ao tocar em 📂 (a activity abre o seletor de arquivos). */
    public Runnable aoPedirArquivo;

    public NavegadorView(Context ctx) {
        super(ctx);
        float d = ctx.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);

        LinearLayout topo = new LinearLayout(ctx);
        topo.setOrientation(HORIZONTAL);
        topo.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView voltar = new TextView(ctx);
        voltar.setText("‹");
        voltar.setTextColor(0xFF5B8CFF);
        voltar.setTextSize(22);
        voltar.setGravity(android.view.Gravity.CENTER);
        voltar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (web.canGoBack()) web.goBack(); }
        });
        topo.addView(voltar, new LayoutParams((int) (36 * d), (int) (36 * d)));

        TextView pacote = new TextView(ctx);
        pacote.setText("📦");
        pacote.setTextSize(16);
        pacote.setGravity(android.view.Gravity.CENTER);
        pacote.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { escolherInstalado(); }
        });
        topo.addView(pacote, new LayoutParams((int) (36 * d), (int) (36 * d)));

        TextView pasta = new TextView(ctx);
        pasta.setText("📂");
        pasta.setTextSize(16);
        pasta.setGravity(android.view.Gravity.CENTER);
        pasta.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (aoPedirArquivo != null) aoPedirArquivo.run(); }
        });
        topo.addView(pasta, new LayoutParams((int) (36 * d), (int) (36 * d)));

        url = new EditText(ctx);
        url.setSingleLine(true);
        url.setTextColor(Color.WHITE);
        url.setHintTextColor(0x88DDE6FF);
        url.setHint("Endereço ou busca");
        url.setTextSize(13);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setImeOptions(EditorInfo.IME_ACTION_GO);
        url.setBackgroundColor(0x22FFFFFF);
        url.setPadding((int) (8 * d), 0, (int) (8 * d), 0);
        url.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, KeyEvent e) {
                ir(url.getText().toString());
                return true;
            }
        });
        topo.addView(url, new LayoutParams(0, (int) (34 * d), 1f));
        addView(topo, new LayoutParams(-1, (int) (36 * d)));

        web = new WebView(ctx);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setAllowFileAccess(true);   // apps/plugins .zip extraídos abrem como file://
        web.setBackgroundColor(0xFF0A0C12);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView w, String u) { if (u != null && !url.hasFocus()) url.setText(u); }
        });
        web.setWebChromeClient(new WebChromeClient());
        addView(web, new LayoutParams(-1, 0, 1f));
        ir("https://www.google.com");
    }

    private void ir(String t) {
        t = t.trim();
        if (t.length() == 0) return;
        String u;
        if (t.startsWith("http://") || t.startsWith("https://") || t.startsWith("file://")) u = t;
        else if (t.contains(".") && !t.contains(" ")) u = "https://" + t;
        else u = "https://www.google.com/search?q=" + android.net.Uri.encode(t);
        web.loadUrl(u);
        url.clearFocus();
    }

    /** Abre um app extraído de .zip (index.html dentro da pasta do pacote; os arquivos vizinhos carregam). */
    public void carregarArquivo(java.io.File index) {
        WebSettings st = web.getSettings();
        st.setAllowFileAccessFromFileURLs(true);
        st.setAllowUniversalAccessFromFileURLs(true);
        url.setText(index.getParentFile().getName());
        web.loadUrl("file://" + index.getAbsolutePath());
    }

    /** 📦: lista os apps/plugins .zip já instalados (Configurações > Arquivos ou 📂 aqui) e abre o escolhido. */
    private void escolherInstalado() {
        final java.io.File[] ds = Pacotes.pasta(getContext()).listFiles();
        final java.util.ArrayList<java.io.File> ok = new java.util.ArrayList<java.io.File>();
        if (ds != null) for (java.io.File f : ds) if (f.isDirectory() && !f.getName().startsWith("cenario_") && Pacotes.acharIndex(f) != null) ok.add(f);
        if (ok.isEmpty()) {
            android.widget.Toast.makeText(getContext(), "Nenhum app instalado. Use 📂 ou Configurações > Arquivos com um .zip.", android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        String[] nomes = new String[ok.size()];
        for (int i = 0; i < nomes.length; i++) nomes[i] = ok.get(i).getName();
        try {
            new android.app.AlertDialog.Builder(getContext()).setTitle("Apps instalados (.zip)").setItems(nomes, new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface dl, int i) { carregarArquivo(Pacotes.acharIndex(ok.get(i))); }
            }).show();
        } catch (Throwable t) { }
    }

    /** Mostra um app/plugin HTML já lido do arquivo. */
    public void carregarHtml(String html, String nome) {
        url.setText(nome);
        web.loadDataWithBaseURL("https://app.local/", html, "text/html", "UTF-8", null);
    }

    /** Libera o WebView ao fechar a janela. */
    public void destruir() {
        web.stopLoading();
        removeAllViews();
        web.destroy();
    }
}
