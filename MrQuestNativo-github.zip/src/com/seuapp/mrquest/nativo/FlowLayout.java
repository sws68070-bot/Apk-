package com.seuapp.mrquest.nativo;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

/**
 * Equivalente nativo de: display:flex; flex-direction:row; flex-wrap:wrap;
 * align-items:center; justify-content:center; align-content:center; gap:14px
 */
public class FlowLayout extends ViewGroup {
    private int gap;
    private boolean centro = true;
    private int[] linhaFim = new int[0];     // índice do primeiro filho da próxima linha
    private int[] linhaLarg = new int[0];
    private int[] linhaAlt = new int[0];
    private int nLinhas;
    private int conteudoAlt;

    public FlowLayout(Context c) { super(c); init(); }
    public FlowLayout(Context c, AttributeSet a) { super(c, a); init(); }
    public FlowLayout(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    /** Modo lista (chips): alinhado à esquerda/topo, com espaço próprio. */
    public FlowLayout modo(int gapPx, boolean centralizar) {
        gap = gapPx; centro = centralizar; requestLayout(); return this;
    }

    private void init() {
        gap = getResources().getDimensionPixelSize(R.dimen.inicio_gap);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int largTotal = MeasureSpec.getSize(wSpec);
        int disp = largTotal - getPaddingLeft() - getPaddingRight();
        int n = getChildCount();
        linhaFim = new int[n + 1];
        linhaLarg = new int[n + 1];
        linhaAlt = new int[n + 1];
        nLinhas = 0;

        int largLinha = 0, altLinha = 0, contLinha = 0;
        for (int i = 0; i < n; i++) {
            View v = getChildAt(i);
            if (v.getVisibility() == GONE) continue;
            v.measure(MeasureSpec.makeMeasureSpec(Math.max(disp, 0), MeasureSpec.AT_MOST),
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
            int w = v.getMeasuredWidth(), h = v.getMeasuredHeight();
            if (contLinha > 0 && largLinha + gap + w > disp) {
                linhaFim[nLinhas] = i; linhaLarg[nLinhas] = largLinha; linhaAlt[nLinhas] = altLinha; nLinhas++;
                largLinha = 0; altLinha = 0; contLinha = 0;
            }
            largLinha += (contLinha > 0 ? gap : 0) + w;
            altLinha = Math.max(altLinha, h);
            contLinha++;
        }
        if (contLinha > 0) {
            linhaFim[nLinhas] = n; linhaLarg[nLinhas] = largLinha; linhaAlt[nLinhas] = altLinha; nLinhas++;
        }

        conteudoAlt = 0;
        for (int l = 0; l < nLinhas; l++) conteudoAlt += linhaAlt[l] + (l > 0 ? gap : 0);
        int altTotal = conteudoAlt + getPaddingTop() + getPaddingBottom();
        setMeasuredDimension(resolveSize(largTotal, wSpec), resolveSize(altTotal, hSpec));
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int larg = r - l, alt = b - t;
        int extra = alt - getPaddingTop() - getPaddingBottom() - conteudoAlt;
        int y = getPaddingTop() + (centro ? Math.max(extra, 0) / 2 : 0);    // align-content:center
        int idx = 0;
        for (int linha = 0; linha < nLinhas; linha++) {
            int x = centro ? (larg - linhaLarg[linha]) / 2 : getPaddingLeft();   // justify-content:center
            int fim = linhaFim[linha];
            for (; idx < fim; idx++) {
                View v = getChildAt(idx);
                if (v.getVisibility() == GONE) continue;
                int w = v.getMeasuredWidth(), h = v.getMeasuredHeight();
                int yy = y + (linhaAlt[linha] - h) / 2;      // align-items:center
                v.layout(x, yy, x + w, yy + h);
                x += w + gap;
            }
            y += linhaAlt[linha] + gap;
        }
    }
}
