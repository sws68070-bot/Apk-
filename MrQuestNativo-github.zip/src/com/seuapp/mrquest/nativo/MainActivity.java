package com.seuapp.mrquest.nativo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

/** Tela inicial nativa do MrQuest (só a tela inicial — etapa 1). */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Estado.init(this);
        setContentView(R.layout.activity_main);

        // Mesmos ids do index.html: go, goVR, goDev, goCfg
        abrirCena(R.id.go,   false);
        abrirCena(R.id.goVR, true);
        findViewById(R.id.goDev).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, DiagActivity.class)); }
        });
        findViewById(R.id.goCfg).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, ConfigActivity.class)); }
        });
    }

    /** Entrar / Entrar em modo VR: abre a cena 3D nativa (no modo VR, duas telas lado a lado). */
    private void abrirCena(int id, final boolean vr) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CenaActivity.class).putExtra("vr", vr));
            }
        });
    }

    private void ligar(int id, final String nome) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { aoClicar(nome); }
        });
    }

    /** Ponto de ligação: aqui entra a próxima etapa (abrir simulação / config / dev). */
    private void aoClicar(String acao) {
        Toast.makeText(this, acao + " — próxima etapa", Toast.LENGTH_SHORT).show();
    }

    // Tela cheia imersiva (equivale ao viewport-fit=cover do HTML)
    private void imersivo() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) imersivo();
    }
}
