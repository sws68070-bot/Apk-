package com.seuapp.mrquest.nativo;

import android.graphics.Color;

/** Cenários do 03-ambiente.js: céu em degradê (pontos 0=topo .. 1=base), cor do chão e cores da grade. */
public final class Cenarios {
    private Cenarios() {}

    public static final class Cen {
        public final float[] t;      // posições do degradê (6, crescentes)
        public final float[] c;      // 6 cores RGB (18 floats)
        public final float[] chao;   // RGB
        public final float[] gMaior, gMenor;   // RGB
        Cen(float[] t, float[] c, float[] chao, float[] gMaior, float[] gMenor) {
            this.t = t; this.c = c; this.chao = chao; this.gMaior = gMaior; this.gMenor = gMenor;
        }
        /** Cor do céu perto do horizonte (usada na névoa de distância). */
        public float[] horizonte() {
            float[] r = new float[3];
            for (int i = 0; i < 5; i++) {
                if (.55f >= t[i] && .55f <= t[i + 1]) {
                    float k = (.55f - t[i]) / Math.max(1e-4f, t[i + 1] - t[i]);
                    for (int j = 0; j < 3; j++) r[j] = c[i * 3 + j] + (c[(i + 1) * 3 + j] - c[i * 3 + j]) * k;
                    return r;
                }
            }
            System.arraycopy(c, 15, r, 0, 3);
            return r;
        }
    }

    public static final String[] CHAVES = {"padrao", "espaco", "por-do-sol", "noite", "floresta", "claro", "amanhecer", "oceano",
            "deserto", "neve", "nebulosa", "cyberpunk", "lava", "aurora", "praia", "campo", "montanha", "cidade", "tempestade", "imagem"};
    public static final String[] NOMES = {"Padrão", "Espaço", "Pôr do sol", "Noite", "Floresta", "Claro", "Amanhecer", "Oceano",
            "Deserto", "Neve", "Nebulosa", "Cyberpunk", "Lava", "Aurora", "Praia", "Campo", "Montanha", "Cidade", "Tempestade", "Minha imagem"};

    // cada linha: degradê "pos:cor,pos:cor..." | chão | grade maior | grade menor  (valores do SCENES do original)
    private static final String[] DEF = {
        "0:0b1030,.45:3b3a7a,.52:d98a6a,.56:6a4458,1:151119|14121c|5566aa|2a3050",
        "0:000000,.5:03040c,1:000000|05050a|223355|101828",
        "0:2b1055,.4:d9534f,.52:ffb347,.56:5a2d3a,1:1a0d10|1a0d10|aa6655|503030",
        "0:02030a,.5:0a1230,1:05060c|07080f|334488|151a30",
        "0:1c3d2a,.45:3f7a4f,.52:b7d99a,.56:2f4a2a,1:14220f|182a14|66aa66|2a4a2a",
        "0:9ec9ff,.5:dbe9ff,.56:c8ccd6,1:a9adb8|b5b9c4|8890a4|a0a6b8",
        "0:0d1b3d,.42:ff9f6b,.52:ffd9a0,.58:3a2e4a,1:141026|1a1526|aa8866|4a3a55",
        "0:0a2a4a,.5:1c6d9e,.56:8fd0e8,1:04141f|062232|2f7ea0|0c3550",
        "0:3f6fb0,.48:f2c979,.55:e08a4f,1:5a3620|8a6338|c9a35a|6b4a2a",
        "0:7fa8d9,.5:dce8f5,.6:f4f8ff,1:c9d6e6|e8eef7|aec4dd|dfe9f5",
        "0:05010f,.35:2a0a4a,.55:7a1f6b,.7:1a0a3a,1:020108|0a0518|6a2a8a|2a1050",
        "0:05021a,.45:3d0a5c,.55:ff2d8a,.7:120a2e,1:05020f|0d0620|ff2d8a|2d0a5c",
        "0:1a0704,.4:5a1505,.55:ff5a1f,.62:2a0c05,1:0d0403|3a0f05|ff6a2a|5a1e0a",
        "0:020815,.3:04162a,.48:0a5a5a,.54:3ddc97,.62:0a1a30,1:01040c|04101c|2dd4a0|0e2a44",
        "0:4fa8ff,.5:a6d8ff,.56:ffe9b8,1:e8cf98|e3d2a3|c9b57a|e7dcb8",
        "0:5fa8e0,.48:bfe0ee,.55:d9f0c2,1:4d7a3a|3f6b30|6fae55|3d602e",
        "0:1b2a55,.4:8a6fa8,.52:ffb27a,.6:3a3050,1:12101f|241f30|8a7aa8|342a4a",
        "0:04040c,.45:160a2a,.55:3a1550,.62:0c0818,1:020106|0a0812|ff5fa8|2a1a4a",
        "0:1a1e28,.4:3a4050,.55:5a6070,.7:22242c,1:0a0b0e|15161b|5a6478|2a2e38"};

    private static float[] rgb(String hex) {
        int c = Color.parseColor("#" + hex);
        return new float[]{Color.red(c) / 255f, Color.green(c) / 255f, Color.blue(c) / 255f};
    }

    private static Cen montar(String def) {
        String[] p = def.split("\\|");
        String[] pts = p[0].split(",");
        float[] t = new float[6], c = new float[18];
        for (int i = 0; i < 6; i++) {
            String[] kv = pts[Math.min(i, pts.length - 1)].split(":");   // repete o último ponto até completar 6
            float[] col = rgb(kv[1]);
            t[i] = i < pts.length ? Float.parseFloat(kv[0]) : 1f;
            System.arraycopy(col, 0, c, i * 3, 3);
        }
        return new Cen(t, c, rgb(p[1]), rgb(p[2]), rgb(p[3]));
    }

    /** Cenário pelo nome; "#rrggbb" vira céu de cor única (como setScene do original); desconhecido = padrão. */
    public static Cen obter(String chave) {
        if (chave != null) {
            for (int i = 0; i < CHAVES.length; i++) if (CHAVES[i].equals(chave)) return montar(i < DEF.length ? DEF[i] : DEF[0]);
            if (chave.matches("#[0-9a-fA-F]{6}")) {
                String h = chave.substring(1);
                return montar("0:" + h + ",.5:" + h + ",1:0a0a0f|0a0a0f|556080|2a3050");
            }
        }
        return montar(DEF[0]);
    }

    public static int indice(String chave) {
        for (int i = 0; i < CHAVES.length; i++) if (CHAVES[i].equals(chave)) return i;
        return 0;
    }
}
