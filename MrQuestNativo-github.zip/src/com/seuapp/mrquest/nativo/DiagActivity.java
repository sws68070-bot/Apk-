package com.seuapp.mrquest.nativo;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** Botão "Desenvolvedor": painel de diagnóstico nativo (equivale ao 20-diagnostico.js). */
public class DiagActivity extends Activity {
    private TextView txt;
    private Pose6Dof pose;
    private final Handler h = new Handler();
    private String ultimo = "";

    private final Runnable atualiza = new Runnable() {
        @Override public void run() {
            ultimo = montar();
            txt.setText(ultimo);
            h.postDelayed(this, 1000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Estado.init(this);
        pose = Pose6Dof.get(this);
        float d = getResources().getDisplayMetrics().density;

        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(0xFF0A0C12);
        raiz.setPadding((int) (12 * d), (int) (10 * d), (int) (12 * d), 0);

        LinearLayout topo = new LinearLayout(this);
        topo.setGravity(Gravity.CENTER_VERTICAL);
        TextView voltar = new TextView(this);
        voltar.setText("‹ Voltar");
        voltar.setTextColor(0xFF5B8CFF);
        voltar.setTextSize(16);
        voltar.setPadding(0, (int) (6 * d), (int) (16 * d), (int) (6 * d));
        voltar.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { finish(); } });
        TextView titulo = new TextView(this);
        titulo.setText("Diagnóstico");
        titulo.setTextColor(Color.WHITE);
        titulo.setTextSize(18);
        titulo.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        Button copiar = new Button(this);
        copiar.setText("Copiar");
        copiar.setAllCaps(false);
        copiar.setTextColor(Color.WHITE);
        copiar.setBackgroundResource(R.drawable.bg_btn_vidro);
        copiar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("diagnóstico", ultimo));
                Toast.makeText(DiagActivity.this, "Diagnóstico copiado", Toast.LENGTH_SHORT).show();
            }
        });
        topo.addView(voltar);
        topo.addView(titulo);
        topo.addView(copiar);
        raiz.addView(topo);

        txt = new TextView(this);
        txt.setTypeface(Typeface.MONOSPACE);
        txt.setTextSize(11);
        txt.setTextColor(0xFFA8F0C8);
        txt.setPadding(0, (int) (8 * d), 0, (int) (16 * d));
        ScrollView sv = new ScrollView(this);
        sv.addView(txt);
        raiz.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(raiz);
    }

    private String montar() {
        StringBuilder s = new StringBuilder();
        Locale L = Locale.US;
        s.append("DIAGNÓSTICO nativo · MrQuest\n");

        s.append("── APARELHO ──\n");
        s.append(String.format(L, "%s %s · Android %s (API %d)\n", Build.MANUFACTURER, Build.MODEL, Build.VERSION.RELEASE, Build.VERSION.SDK_INT));
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        s.append(String.format(L, "núcleos %d · RAM %d MB (livre %d MB%s)\n", Runtime.getRuntime().availableProcessors(),
                mi.totalMem / 1048576, mi.availMem / 1048576, mi.lowMemory ? " · POUCA" : ""));
        Runtime rt = Runtime.getRuntime();
        s.append(String.format(L, "heap Java %d/%d MB\n", (rt.totalMemory() - rt.freeMemory()) / 1048576, rt.maxMemory() / 1048576));
        DisplayMetrics dm = getResources().getDisplayMetrics();
        s.append(String.format(L, "tela %dx%d px · dpi %.0f · %.0f Hz\n", dm.widthPixels, dm.heightPixels, dm.densityDpi + 0f,
                getWindowManager().getDefaultDisplay().getRefreshRate()));
        Intent bat = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            int lv = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), sc = bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int pl = bat.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0), tp = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
            s.append(String.format(L, "bateria %d%%%s · %.1f °C\n", lv * 100 / Math.max(1, sc), pl != 0 ? " (carregando)" : "", tp / 10f));
        }

        s.append("── SENSORES ──\n");
        SensorManager sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        s.append("giroscópio ").append(tem(sm, Sensor.TYPE_GYROSCOPE));
        s.append(" · rot.vetor jogo ").append(tem(sm, Sensor.TYPE_GAME_ROTATION_VECTOR));
        s.append(" · rot.vetor ").append(tem(sm, Sensor.TYPE_ROTATION_VECTOR)).append('\n');
        s.append("acelerômetro ").append(tem(sm, Sensor.TYPE_ACCELEROMETER));
        s.append(" · linear ").append(tem(sm, Sensor.TYPE_LINEAR_ACCELERATION));
        s.append(" · bússola ").append(tem(sm, Sensor.TYPE_MAGNETIC_FIELD)).append('\n');

        s.append("── CENA 3D ──\n");
        if (CenaRenderer.fps > 0) s.append(String.format(L, "fps %.0f · quadro %.1f ms (pior %.0f ms)\n", CenaRenderer.fps, CenaRenderer.ms, CenaRenderer.pior));
        else s.append("cena fechada (abra Entrar para medir fps)\n");

        s.append(String.format(L, "limite %s · resolução %s · modo desempenho %s\n", Estado.i("ui_fps", 30) > 0 ? Estado.i("ui_fps", 30) + " fps" : "livre",
                new String[]{"Auto", "Alta", "Média", "Baixa"}[Math.max(0, Math.min(3, Estado.i("ui_res", 0)))], Estado.b("ui_perf", true) ? "ligado" : "desligado"));
        s.append("câmera passthrough: ").append(CenaRenderer.camEstado).append('\n');
        s.append("mão (MediaPipe): ").append(CenaRenderer.maoEstado).append('\n');
        s.append("── 6DOF SIMULADO ──\n");
        s.append(pose.rodando() ? "ligado\n" : "desligado (liga ao entrar na cena)\n");
        try { s.append(pose.status()).append('\n'); } catch (Exception e) { s.append("(sem leitura)\n"); }
        return s.toString();
    }

    private static String tem(SensorManager sm, int tipo) { return sm.getDefaultSensor(tipo) != null ? "sim" : "não"; }

    @Override protected void onResume() { super.onResume(); h.post(atualiza); }
    @Override protected void onPause() { h.removeCallbacks(atualiza); super.onPause(); }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
}
