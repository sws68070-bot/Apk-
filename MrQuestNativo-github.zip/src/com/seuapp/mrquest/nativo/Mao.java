package com.seuapp.mrquest.nativo;

import android.content.Context;
import android.graphics.Bitmap;

/**
 * Detecção de mão. A implementação com MediaPipe fica em src_mao/ (MaoMediaPipe) e só entra no APK
 * se o build.sh conseguir baixar as bibliotecas; a Activity a carrega por reflexão, então o app compila e roda sem ela.
 */
public interface Mao {
    interface Ouvinte {
        /** xs/ys: 21 pontos normalizados (0..1) no quadro enviado, y para baixo. Ambos null = sem mão. */
        void resultado(float[] xs, float[] ys);
    }

    void iniciar(Context c, Ouvinte o);
    void parar();
    /** true se pode receber outro quadro agora (a detecção anterior já terminou). */
    boolean livre();
    void enviar(Bitmap quadroEmPe, long tsMs);
    String estado();
}
