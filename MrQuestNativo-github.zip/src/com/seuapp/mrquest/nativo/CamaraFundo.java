package com.seuapp.mrquest.nativo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.Image;
import android.media.ImageReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;
import android.view.Surface;


/**
 * Câmera traseira (Camera2) desenhando direto numa textura do OpenGL: é o "passthrough" da cena.
 * Pede resolução baixa (~640x480) de propósito: a cena só usa como fundo e isso poupa CPU/GPU no celular fraco.
 */
public class CamaraFundo {
    private final Context ctx;
    private CameraDevice dev;
    private CameraCaptureSession ses;
    private HandlerThread ht;
    private Handler hd;
    private boolean aberta;

    public volatile int sensorOri = 90;
    public volatile int largura = 640, altura = 480;
    public volatile String estado = "desligada";

    /** Quadro pequeno (320x240, de pé) para a detecção de mão. */
    public interface Leitor { boolean quer(); void quadro(Bitmap emPe, long tsMs); }
    public volatile Leitor leitor;
    public volatile int rotacao;          // graus: sensor - rotação da tela (a Activity mantém atualizado)
    private ImageReader leitorImg;
    private int[] px;

    private Bitmap converter(Image im) {
        int w = im.getWidth(), h = im.getHeight();
        Image.Plane[] p = im.getPlanes();
        ByteBuffer yb = p[0].getBuffer(), ub = p[1].getBuffer(), vb = p[2].getBuffer();
        int ys = p[0].getRowStride(), us = p[1].getRowStride(), up = p[1].getPixelStride(), vs = p[2].getRowStride(), vp = p[2].getPixelStride();
        if (px == null || px.length != w * h) px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int Y = yb.get(y * ys + x) & 0xFF;
            int U = (ub.get((y >> 1) * us + (x >> 1) * up) & 0xFF) - 128, V = (vb.get((y >> 1) * vs + (x >> 1) * vp) & 0xFF) - 128;
            int r = Y + (int) (1.402f * V), g = Y - (int) (.344f * U + .714f * V), b = Y + (int) (1.772f * U);
            r = r < 0 ? 0 : (r > 255 ? 255 : r); g = g < 0 ? 0 : (g > 255 ? 255 : g); b = b < 0 ? 0 : (b > 255 ? 255 : b);
            px[y * w + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
        }
        Bitmap bm = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
        int rot = rotacao;
        if (rot == 0) return bm;
        Matrix m = new Matrix();
        m.postRotate(rot);
        return Bitmap.createBitmap(bm, 0, 0, w, h, m, true);
    }


    public CamaraFundo(Context c) { ctx = c.getApplicationContext(); }

    public static boolean temPermissao(Context c) {
        return Build.VERSION.SDK_INT < 23 || c.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    public synchronized void iniciar(final SurfaceTexture st) {
        if (aberta) return;
        if (!temPermissao(ctx)) { estado = "sem permissão"; return; }
        try {
            CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            for (String i : cm.getCameraIdList()) {
                Integer f = cm.getCameraCharacteristics(i).get(CameraCharacteristics.LENS_FACING);
                if (f != null && f == CameraCharacteristics.LENS_FACING_BACK) { id = i; break; }
            }
            if (id == null) { estado = "sem câmera traseira"; return; }
            CameraCharacteristics cc = cm.getCameraCharacteristics(id);
            Integer so = cc.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOri = so == null ? 90 : so;
            StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size melhor = new Size(640, 480);
            if (map != null) {
                Size[] ts = map.getOutputSizes(SurfaceTexture.class);
                long alvo = 640L * 480L, dif = Long.MAX_VALUE;
                if (ts != null) for (Size s : ts) {
                    if (Math.abs(s.getWidth() * 3 - s.getHeight() * 4) > 16) continue;     // só 4:3
                    long d = Math.abs((long) s.getWidth() * s.getHeight() - alvo);
                    if (d < dif) { dif = d; melhor = s; }
                }
            }
            largura = melhor.getWidth();
            altura = melhor.getHeight();
            st.setDefaultBufferSize(largura, altura);
            final Surface surf = new Surface(st);

            ht = new HandlerThread("camera-fundo");
            ht.start();
            hd = new Handler(ht.getLooper());
            aberta = true;
            estado = "abrindo";
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) {
                    dev = c;
                    try {
                        List<Surface> saidas = new ArrayList<Surface>();
                        saidas.add(surf);
                        if (leitor != null) {
                            leitorImg = ImageReader.newInstance(320, 240, ImageFormat.YUV_420_888, 2);
                            leitorImg.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                                @Override public void onImageAvailable(ImageReader r) {
                                    Image im = null;
                                    try {
                                        im = r.acquireLatestImage();
                                        Leitor le = leitor;
                                        if (im == null || le == null || !le.quer()) return;
                                        le.quadro(converter(im), android.os.SystemClock.uptimeMillis());
                                    } catch (Exception e) { }
                                    finally { if (im != null) im.close(); }
                                }
                            }, hd);
                            saidas.add(leitorImg.getSurface());
                        }
                        c.createCaptureSession(saidas, new CameraCaptureSession.StateCallback() {
                            @Override public void onConfigured(CameraCaptureSession s) {
                                ses = s;
                                try {
                                    CaptureRequest.Builder rb = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                    rb.addTarget(surf);
                                    if (leitorImg != null) rb.addTarget(leitorImg.getSurface());
                                    rb.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
                                    rb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                                    s.setRepeatingRequest(rb.build(), null, hd);
                                    estado = "ligada " + largura + "x" + altura;
                                } catch (Exception e) { estado = "erro: " + e.getMessage(); }
                            }
                            @Override public void onConfigureFailed(CameraCaptureSession s) { estado = "falha ao configurar"; }
                        }, hd);
                    } catch (Exception e) { estado = "erro: " + e.getMessage(); }
                }
                @Override public void onDisconnected(CameraDevice c) { estado = "desconectada"; c.close(); }
                @Override public void onError(CameraDevice c, int e) { estado = "erro " + e; c.close(); }
            }, hd);
        } catch (CameraAccessException e) {
            estado = "erro: " + e.getMessage();
            aberta = false;
        } catch (SecurityException e) {
            estado = "sem permissão";
            aberta = false;
        }
    }

    public synchronized void parar() {
        try { if (ses != null) ses.close(); } catch (Exception e) { }
        try { if (dev != null) dev.close(); } catch (Exception e) { }
        ses = null;
        dev = null;
        if (leitorImg != null) { try { leitorImg.close(); } catch (Exception e) { } leitorImg = null; }
        if (ht != null) { ht.quitSafely(); ht = null; }
        aberta = false;
        estado = "desligada";
    }
}
