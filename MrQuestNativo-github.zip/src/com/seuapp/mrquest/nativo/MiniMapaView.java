package com.seuapp.mrquest.nativo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Vista de cima do 6DOF simulado: trilha do que você andou + seta do olhar. */
public class MiniMapaView extends View {
    private final Pose6Dof p;
    private final Paint fundo = new Paint(Paint.ANTI_ALIAS_FLAG), grade = new Paint(Paint.ANTI_ALIAS_FLAG),
            trilha = new Paint(Paint.ANTI_ALIAS_FLAG), ponto = new Paint(Paint.ANTI_ALIAS_FLAG),
            cone = new Paint(Paint.ANTI_ALIAS_FLAG), texto = new Paint(Paint.ANTI_ALIAS_FLAG),
            origem = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private final Path path = new Path();
    private final Runnable laco = new Runnable() {
        @Override public void run() { invalidate(); postDelayed(this, 50); }
    };

    public MiniMapaView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        p = Pose6Dof.get(c);
        fundo.setColor(0xFF0F1218);
        grade.setColor(0x1AFFFFFF); grade.setStrokeWidth(1f * d); grade.setStyle(Paint.Style.STROKE);
        trilha.setColor(0xFF5B8CFF); trilha.setStrokeWidth(2.5f * d); trilha.setStyle(Paint.Style.STROKE);
        trilha.setStrokeCap(Paint.Cap.ROUND); trilha.setStrokeJoin(Paint.Join.ROUND);
        ponto.setColor(0xFFFFFFFF);
        cone.setColor(0x445B8CFF);
        origem.setColor(0xFF86EFAC);
        texto.setColor(0xFF64748B); texto.setTextSize(11f * d);
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); post(laco); }
    @Override protected void onDetachedFromWindow() { removeCallbacks(laco); super.onDetachedFromWindow(); }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(resolveSize(MeasureSpec.getSize(w), w), Math.round(220 * d));
    }

    @Override
    protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight();
        c.drawRoundRect(new RectF(0, 0, W, H), 12 * d, 12 * d, fundo);

        // limites (origem, trilha e posição atual)
        float mnx = Math.min(0, p.x), mxx = Math.max(0, p.x), mnz = Math.min(0, p.z), mxz = Math.max(0, p.z);
        int n = p.trilhaN();
        for (int i = 0; i < n; i++) {
            float tx = p.trilhaX(i), tz = p.trilhaZ(i);
            mnx = Math.min(mnx, tx); mxx = Math.max(mxx, tx); mnz = Math.min(mnz, tz); mxz = Math.max(mxz, tz);
        }
        float ex = Math.max(mxx - mnx, 4f) * 1.4f, ez = Math.max(mxz - mnz, 4f) * 1.4f;
        float s = Math.min(W / ex, H / ez);                      // pixels por metro
        float cx = (mnx + mxx) / 2, cz = (mnz + mxz) / 2;

        // grade (1, 2, 5, 10 ... m)
        float passo = 1f;
        while (passo * s < 28 * d) passo *= (passo < 2 ? 2 : passo < 5 ? 2.5f : 2f);
        float x0 = cx - W / 2 / s, x1 = cx + W / 2 / s, z0 = cz - H / 2 / s, z1 = cz + H / 2 / s;
        for (float gx = (float) Math.ceil(x0 / passo) * passo; gx <= x1; gx += passo)
            c.drawLine(W / 2 + (gx - cx) * s, 0, W / 2 + (gx - cx) * s, H, grade);
        for (float gz = (float) Math.ceil(z0 / passo) * passo; gz <= z1; gz += passo)
            c.drawLine(0, H / 2 + (gz - cz) * s, W, H / 2 + (gz - cz) * s, grade);

        // origem
        c.drawCircle(W / 2 + (0 - cx) * s, H / 2 + (0 - cz) * s, 4 * d, origem);

        // trilha
        path.reset();
        for (int i = 0; i < n; i++) {
            float px = W / 2 + (p.trilhaX(i) - cx) * s, pz = H / 2 + (p.trilhaZ(i) - cz) * s;
            if (i == 0) path.moveTo(px, pz); else path.lineTo(px, pz);
        }
        if (n > 1) c.drawPath(path, trilha);

        // você + cone de visão
        float ux = W / 2 + (p.x - cx) * s, uz = H / 2 + (p.z - cz) * s;
        float sy = (float) Math.sin(p.yaw), cy = (float) Math.cos(p.yaw);
        float fx = sy, fz = -cy, rx = cy, rz = sy;                 // frente e direita em tela
        float L = 38 * d;
        path.reset();
        path.moveTo(ux, uz);
        path.lineTo(ux + (fx * L - rx * L * .45f), uz + (fz * L - rz * L * .45f));
        path.lineTo(ux + (fx * L + rx * L * .45f), uz + (fz * L + rz * L * .45f));
        path.close();
        c.drawPath(path, cone);
        c.drawCircle(ux, uz, 6 * d, ponto);

        c.drawText("grade: " + (passo == (int) passo ? String.valueOf((int) passo) : String.valueOf(passo)) + " m", 8 * d, H - 8 * d, texto);
        c.drawText("▲ frente inicial", W - 100 * d, 16 * d, texto);
    }
}
