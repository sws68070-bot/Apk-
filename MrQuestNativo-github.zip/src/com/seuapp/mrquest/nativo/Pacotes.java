package com.seuapp.mrquest.nativo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Apps/plugins/cenários em .zip (extração segura) e a imagem de cenário (céu panorâmico). */
public final class Pacotes {
    private Pacotes() {}

    private static final long LIMITE = 300L * 1024 * 1024;   // teto do que um .zip pode ocupar descompactado

    public static File pasta(Context c) {
        File f = new File(c.getFilesDir(), "pacotes");
        f.mkdirs();
        return f;
    }

    public static String limpar(String nome) {
        if (nome == null) nome = "pacote";
        String b = nome.replaceAll("(?i)\\.zip$", "").replaceAll("[^A-Za-z0-9._-]", "_");
        return b.length() == 0 ? "pacote" : b;
    }

    private static void apagar(File f) {
        File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) apagar(x);
        f.delete();
    }

    /** Extrai o .zip para files/pacotes/&lt;nome&gt;. Ignora entradas que tentam sair da pasta (zip-slip). */
    public static File extrairZip(Context c, android.net.Uri u, String nome) throws IOException {
        File base = new File(pasta(c), limpar(nome));
        apagar(base);
        base.mkdirs();
        String raiz = base.getCanonicalPath() + File.separator;
        InputStream in = c.getContentResolver().openInputStream(u);
        if (in == null) throw new IOException("sem acesso ao arquivo");
        ZipInputStream z = new ZipInputStream(in);
        try {
            ZipEntry e;
            byte[] buf = new byte[16384];
            long total = 0;
            while ((e = z.getNextEntry()) != null) {
                File f = new File(base, e.getName());
                if (!f.getCanonicalPath().startsWith(raiz)) continue;
                if (e.isDirectory()) { f.mkdirs(); continue; }
                f.getParentFile().mkdirs();
                FileOutputStream o = new FileOutputStream(f);
                try {
                    int n;
                    while ((n = z.read(buf)) > 0) {
                        total += n;
                        if (total > LIMITE) throw new IOException("zip grande demais");
                        o.write(buf, 0, n);
                    }
                } finally { o.close(); }
            }
        } finally { z.close(); }
        return base;
    }

    /** index.html na raiz ou numa subpasta (até 2 níveis). */
    public static File acharIndex(File dir) { return achar(dir, 0); }

    private static File achar(File d, int nivel) {
        File i = new File(d, "index.html");
        if (i.isFile()) return i;
        if (nivel >= 2) return null;
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) if (f.isDirectory()) { File r = achar(f, nivel + 1); if (r != null) return r; }
        return null;
    }

    public static File primeiraImagem(File d) {
        File[] fs = d.listFiles();
        if (fs == null) return null;
        for (File f : fs) {
            String n = f.getName().toLowerCase();
            if (f.isFile() && (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp"))) return f;
        }
        for (File f : fs) if (f.isDirectory()) { File r = primeiraImagem(f); if (r != null) return r; }
        return null;
    }

    /** Reduz a imagem (lado maior ≤ 2048) e guarda em files/cenario_img.jpg. */
    public static boolean salvarImagemCeu(Context c, InputStream in) {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            long tot = 0;
            while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); tot += n; if (tot > 60L * 1024 * 1024) return false; }
            in.close();
            byte[] d = bo.toByteArray();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(d, 0, d.length, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return false;
            int amostra = 1;
            while (Math.max(o.outWidth, o.outHeight) / amostra > 4096) amostra *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = amostra;
            Bitmap b = BitmapFactory.decodeByteArray(d, 0, d.length, o);
            if (b == null) return false;
            int m = Math.max(b.getWidth(), b.getHeight());
            if (m > 2048) {
                float k = 2048f / m;
                Bitmap s = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * k)), Math.max(1, Math.round(b.getHeight() * k)), true);
                if (s != b) b.recycle();
                b = s;
            }
            FileOutputStream fo = new FileOutputStream(new File(c.getFilesDir(), "cenario_img.jpg"));
            try { b.compress(Bitmap.CompressFormat.JPEG, 90, fo); } finally { fo.close(); }
            b.recycle();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
