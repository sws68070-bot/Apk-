package com.seuapp.mrquest.nativo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Surface;
import android.view.WindowManager;

import java.util.Locale;

/**
 * 6DOF SIMULADO (sem câmera) — porte nativo de 13-orientacao.js + 16-andar.js.
 *
 *  · Rotação (3DOF): vetor de rotação do giroscópio (ou só inclinação pelo acelerômetro),
 *    com a "suavidade da visão" (anti-tremedeira) e zona de repouso quando o aparelho está parado.
 *  · Posição (+3DOF): contagem de passos pelo acelerômetro, andando para onde a cabeça aponta,
 *    ou GPS. Altura travada (ou integrada pelo acelerômetro, se liberado).
 *
 * Convenção do app: x = direita, y = altura, z = pra trás. Yaw 0 olha para -z; yaw positivo gira pra direita.
 */
public final class Pose6Dof implements SensorEventListener, LocationListener {

    private static Pose6Dof inst;

    public static synchronized Pose6Dof get(Context c) {
        if (inst == null) inst = new Pose6Dof(c.getApplicationContext());
        return inst;
    }

    // ---- pose (lida pela interface) ----
    public float yaw, pitch, roll;          // radianos, já suavizados
    public float x, y = 1.4f, z;            // metros
    public int passos;
    public float distancia;
    public String fonte = "—";
    public boolean parado;
    public String gpsEstado = "desligado";
    public boolean calOn;
    public int calPassos;

    // ---- trilha ----
    public static final int TRILHA_MAX = 600;
    private final float[] trX = new float[TRILHA_MAX], trZ = new float[TRILHA_MAX];
    private int trTotal;

    private final Context ctx;
    private final SensorManager sm;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean rodando;

    // ---- configuração (cache; recarregada por recarregar()) ----
    private boolean cOn = true, cVlk = true, cVert = true, cVacc = true, cStl = true, cGps;
    private float cEsc = 1, cGfw = 1, cGrt = 1, cHh = 1.4f, cPlen = .65f, cPsl = 1, cHcl = 2.6f, cStk = 1;
    private int cSent = 1, cSuave = 2;

    // ---- orientação ----
    private int tipoRot = -1;
    private final float[] vec = new float[4], rRaw = new float[9], rScr = new float[9];
    private float yawAcc, ultH, offAbs, tPitch, tRoll;
    private boolean temH;
    private float gx, gy, gz; private boolean temG;           // gravidade filtrada (fallback)
    private long ultMov;

    // ---- passos ----
    private float L; private boolean arm = true;
    private long ultPasso, tPrev, tUlt; private boolean andando;
    private float tgt, feito;
    private long ultAcel;
    private float vz, uz;                                      // velocidade/aceleração vertical
    private long ultQuieto;

    // ---- GPS ----
    private LocationManager lm;
    private boolean gpsTem;
    private double lat0, lon0;
    private float gfx, gfy, gtx, gty, gax, gay;

    private long ultTick; private int nTick;

    private Pose6Dof(Context c) {
        ctx = c;
        sm = (SensorManager) c.getSystemService(Context.SENSOR_SERVICE);
        Estado.init(c);
    }

    // ================= ciclo de vida =================
    public synchronized void iniciar() {
        if (rodando) return;
        rodando = true;
        recarregar();
        boolean bussola = Estado.b("6d_bussola", false) || cGps;
        Sensor rot = sm.getDefaultSensor(bussola ? Sensor.TYPE_ROTATION_VECTOR : Sensor.TYPE_GAME_ROTATION_VECTOR);
        if (rot == null) rot = sm.getDefaultSensor(bussola ? Sensor.TYPE_GAME_ROTATION_VECTOR : Sensor.TYPE_ROTATION_VECTOR);
        Sensor lin = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        Sensor ac = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (rot != null) {
            tipoRot = rot.getType();
            sm.registerListener(this, rot, SensorManager.SENSOR_DELAY_GAME);
            fonte = tipoRot == Sensor.TYPE_ROTATION_VECTOR ? "giroscópio + bússola" : "giroscópio";
        } else {
            tipoRot = -1;
            fonte = ac != null ? "inclinação (sem giroscópio)" : "nenhum sensor";
        }
        if (lin != null) { sm.registerListener(this, lin, SensorManager.SENSOR_DELAY_GAME); L = 0; }
        if (ac != null && (lin == null || rot == null)) {
            sm.registerListener(this, ac, SensorManager.SENSOR_DELAY_GAME);
            if (lin == null) L = 9.8f;
        }
        temH = false; temG = false; ultMov = SystemClock.elapsedRealtime();
        if (cGps) iniciarGps(); else gpsEstado = "desligado";
        ultTick = System.nanoTime();
        h.post(tick);
    }

    public synchronized void parar() {
        if (!rodando) return;
        rodando = false;
        sm.unregisterListener(this);
        h.removeCallbacks(tick);
        pararGps();
    }

    public void reiniciar() { parar(); iniciar(); }

    public boolean rodando() { return rodando; }

    /** Relê as opções salvas. */
    public void recarregar() {
        cOn = Estado.b("6d_on", true);
        cGps = "gps".equals(Estado.s("6d_modo", "passos"));
        cEsc = Estado.f("6d_esc", 1f);
        cGfw = Estado.f("6d_gfw", 1f);
        cGrt = Estado.f("6d_grt", 1f);
        cHh = Estado.f("6d_hh", 1.4f);
        cVlk = Estado.b("6d_vlk", true);
        cVert = Estado.b("6d_vert", true);
        cVacc = Estado.b("6d_vacc", true);
        cPlen = Estado.f("6d_plen", .65f);
        cPsl = Estado.f("6d_psl", 1f);
        cHcl = Estado.f("6d_hcl", 2.6f);
        cStl = Estado.b("6d_stl", true);
        cStk = Estado.f("6d_stk", 1f);
        cSent = Estado.i("6d_sent", 1);
        cSuave = Estado.i("vs", 2);
    }

    // ================= ações =================
    public void recentrar() { yawAcc = 0; yaw = 0; }

    /** Controle (analógico direito): gira a visão, em radianos (positivo = para a direita). */
    public void giroExtra(float dyaw) { yawAcc += dyaw; }

    /** Controle (analógico esquerdo): anda em metros, para frente e para o lado, conforme o olhar. */
    public void andarDireto(float frente, float lado) {
        x += (float) (Math.sin(yaw) * frente + Math.cos(yaw) * lado);
        z += (float) (-Math.cos(yaw) * frente + Math.sin(yaw) * lado);
    }

    public void zerar() {
        x = 0; z = 0; y = cHh; tgt = feito = 0; passos = 0; distancia = 0; vz = 0;
        trTotal = 0; calOn = false; calPassos = 0;
        gpsTem = false; gfx = gfy = gtx = gty = gax = gay = 0;
    }

    /** Passo de teste (botões ▲/▼ da config). */
    public void passoManual(int sinal) {
        tgt += sinal * cPlen * cEsc * cGfw;
        passos++;
        if (calOn) calPassos++;
    }

    /** Calibrar distância: 1º toque começa a contar os passos; 2º toque (ao chegar) calcula o passo. */
    public String calibrar() {
        float real = Estado.f("6d_cdr", 2f);
        if (!calOn) { calOn = true; calPassos = 0; return "Ande " + fmt(real) + " m em linha reta e toque de novo"; }
        calOn = false;
        if (calPassos < 2) return "Poucos passos contados — tente de novo";
        float p = Estado.limitar(Estado.arred(real / calPassos), .3f, 1.2f);
        Estado.put("6d_plen", p); cPlen = p;
        return calPassos + " passos → passo de " + fmt(p) + " m";
    }

    public void padroes() {
        Estado.remover("6d_");
        recarregar();
        zerar();
    }

    // ================= trilha =================
    public int trilhaN() { return Math.min(trTotal, TRILHA_MAX); }
    public float trilhaX(int i) { return trX[(inicioTrilha() + i) % TRILHA_MAX]; }
    public float trilhaZ(int i) { return trZ[(inicioTrilha() + i) % TRILHA_MAX]; }
    private int inicioTrilha() { return trTotal > TRILHA_MAX ? trTotal % TRILHA_MAX : 0; }

    private void marcar() {
        int n = trilhaN();
        if (n > 0) {
            float dx = x - trilhaX(n - 1), dz = z - trilhaZ(n - 1);
            if (dx * dx + dz * dz < .0025f) return;           // só a cada ~5 cm
        }
        int i = trTotal % TRILHA_MAX;
        trX[i] = x; trZ[i] = z; trTotal++;
    }

    // ================= sensores =================
    @Override public void onAccuracyChanged(Sensor s, int a) {}

    @Override
    public void onSensorChanged(SensorEvent e) {
        switch (e.sensor.getType()) {
            case Sensor.TYPE_GAME_ROTATION_VECTOR:
            case Sensor.TYPE_ROTATION_VECTOR:
                if (e.sensor.getType() != tipoRot) return;
                int n = Math.min(4, e.values.length);
                System.arraycopy(e.values, 0, vec, 0, n);
                if (n < 4) vec[3] = 0;
                try {
                    SensorManager.getRotationMatrixFromVector(rRaw, n < 4 ? new float[]{vec[0], vec[1], vec[2]} : vec);
                } catch (IllegalArgumentException ex) { return; }
                orientar();
                break;
            case Sensor.TYPE_LINEAR_ACCELERATION:
                movimento(e.values[0], e.values[1], e.values[2], false);
                break;
            case Sensor.TYPE_ACCELEROMETER:
                if (tipoRot < 0) inclinacao(e.values[0], e.values[1], e.values[2]);
                if (sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION) == null)
                    movimento(e.values[0], e.values[1], e.values[2], true);
                break;
        }
    }

    private int rotacaoTela() {
        try {
            return ((WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRotation();
        } catch (Exception ex) { return Surface.ROTATION_90; }
    }

    private static float envolve(float a) {
        while (a > Math.PI) a -= 2 * Math.PI;
        while (a < -Math.PI) a += 2 * Math.PI;
        return a;
    }

    /** Vetor de rotação → direção do olhar (a câmera de trás aponta para -z do aparelho). */
    private void orientar() {
        int rot = rotacaoTela();
        int ax, ay;
        switch (rot) {
            case Surface.ROTATION_90:  ax = SensorManager.AXIS_Y;       ay = SensorManager.AXIS_MINUS_X; break;
            case Surface.ROTATION_180: ax = SensorManager.AXIS_MINUS_X; ay = SensorManager.AXIS_MINUS_Y; break;
            case Surface.ROTATION_270: ax = SensorManager.AXIS_MINUS_Y; ay = SensorManager.AXIS_X;       break;
            default:                   ax = SensorManager.AXIS_X;       ay = SensorManager.AXIS_Y;
        }
        SensorManager.remapCoordinateSystem(rRaw, ax, ay, rScr);
        // olhar no mundo (leste, norte, cima) = R · (0,0,-1)
        float fe = -rScr[2], fn = -rScr[5], fu = -rScr[8];
        float horiz = (float) Math.hypot(fe, fn);
        long agora = SystemClock.elapsedRealtime();

        float np = (float) Math.asin(Estado.limitar(fu, -1f, 1f));
        float nr = tRoll;
        if (Math.hypot(rScr[6], rScr[7]) > .12) nr = (float) Math.atan2(rScr[6], rScr[7]);

        float mov = Math.abs(np - tPitch) + Math.abs(envolve(nr - tRoll));
        if (horiz > .25f) {
            float hAbs = (float) Math.atan2(fe, fn);
            if (!temH) { ultH = hAbs; temH = true; }
            float dh = envolve(hAbs - ultH);
            mov += Math.abs(dh);
            yawAcc += dh * cGrt;
            ultH = hAbs;
            offAbs = hAbs - yawAcc;
        }
        tPitch = np; tRoll = nr;
        if (mov > .0008f) ultMov = agora;              // girando de verdade (>~2°/s a 50 Hz)
    }

    /** Sem giroscópio: inclinação pela gravidade (a rotação lateral não existe). */
    private void inclinacao(float ax, float ay, float az) {
        float ux, uy;
        switch (rotacaoTela()) {
            case Surface.ROTATION_90:  ux = ay;  uy = -ax; break;
            case Surface.ROTATION_180: ux = -ax; uy = -ay; break;
            case Surface.ROTATION_270: ux = -ay; uy = ax;  break;
            default:                   ux = ax;  uy = ay;
        }
        if (!temG) { gx = ux; gy = uy; gz = az; temG = true; }
        gx += (ux - gx) * .15f; gy += (uy - gy) * .15f; gz += (az - gz) * .15f;
        float n = (float) Math.sqrt(gx * gx + gy * gy + gz * gz);
        if (n < 3) return;
        tPitch = (float) Math.asin(Estado.limitar(-gz / n, -1f, 1f));
        if (Math.hypot(gx, gy) / n > .12) tRoll = (float) Math.atan2(gx, gy);
    }

    /** Acelerômetro: detector de passos (mesma regra do 16-andar.js) + aceleração vertical. */
    private void movimento(float ax, float ay, float az, boolean comGravidade) {
        long t = SystemClock.elapsedRealtime();
        float dt = ultAcel == 0 ? .02f : Math.min(.1f, (t - ultAcel) / 1000f);
        ultAcel = t;
        float m = (float) Math.sqrt(ax * ax + ay * ay + az * az);
        L += (m - L) * .03f;
        float hh = m - L;                                    // pico do balanço da caminhada acima da média
        if (cOn && !cGps) {
            if (arm && hh > cPsl && t - ultPasso > 300) { arm = false; ultPasso = t; passoDado(t); }
            else if (!arm && hh < .4f * cPsl) arm = true;
        }
        if (Math.abs(hh) > .6f * cPsl * .5f) ultMov = t;     // tremor do aparelho também conta como "mexendo"

        // aceleração vertical no mundo (R[6..8] = linha "cima" da matriz de rotação)
        if (tipoRot >= 0) {
            float upz = rRaw[6] * ax + rRaw[7] * ay + rRaw[8] * az;
            uz = comGravidade ? upz - 9.81f : upz;
            if (Math.abs(uz) < .15f) { if (ultQuieto == 0) ultQuieto = t; } else ultQuieto = 0;
            if (cOn && cVert && cVacc && !cVlk) {
                vz += uz * dt;
                vz *= (float) Math.exp(-dt * 1.5);           // filtra a deriva
                if (ultQuieto != 0 && t - ultQuieto > 300) vz = 0;   // parado ~0,3 s: velocidade zero
            } else vz = 0;
        }
    }

    private void passoDado(long t) {
        long prev = tUlt; tUlt = t;
        if (prev == 0 || t - prev > 1100) { andando = false; return; }   // passo isolado não conta: precisa de cadência
        int add = andando ? 1 : 2;                                       // o 2º passo confirma e conta junto com o 1º
        andando = true;
        tgt += cSent * add * cPlen * cEsc * cGfw;
        passos += add;
        if (calOn) calPassos += add;
    }

    // ================= laço principal (~60 Hz) =================
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!rodando) return;
            long agoraN = System.nanoTime();
            float dt = Math.max(.001f, Math.min(.1f, (agoraN - ultTick) / 1e9f));
            ultTick = agoraN;
            if ((nTick++ & 15) == 0) recarregar();
            passo(dt);
            h.postDelayed(this, 16);
        }
    };

    private static final float[] TAU = {0f, .07f, .13f, .22f};

    private static float vsTau(float tm, float e) {
        float a = e / .005f, b = e / .035f;
        return Math.max(.012f, tm * (1 + 4 / (1 + a * a)) / (1 + b * b));
    }

    private void passo(float dt) {
        long t = SystemClock.elapsedRealtime();
        parado = t - ultMov > 300;
        if (andando && t - ultPasso > 1300) andando = false;

        // --- suavidade da visão (anti-tremedeira) com zona de repouso ---
        float alvoY = yawAcc;
        if (cSuave <= 0) { yaw = alvoY; pitch = tPitch; roll = tRoll; }
        else {
            float ey = alvoY - yaw, ep = tPitch - pitch, er = envolve(tRoll - roll);
            float e = Math.max(Math.abs(ey), Math.max(Math.abs(ep), Math.abs(er)));
            float a = 1 - (float) Math.exp(-dt / vsTau(TAU[Math.min(3, cSuave)], e));
            float db = (cStl && parado) ? .0021f * cStk : 0f;     // ~0,12° quando parado
            yaw += zona(ey, db) * a; pitch += zona(ep, db) * a; roll += zona(er, db) * a;
        }

        // --- posição ---
        if (cOn) {
            if (cGps) gpsPasso(dt);
            else if (Math.abs(tgt - feito) > 1e-4f) {
                float dz = (tgt - feito) * (1 - (float) Math.exp(-dt * 7));
                feito += dz;
                x += (float) Math.sin(yaw) * dz;
                z -= (float) Math.cos(yaw) * dz;
                distancia += Math.abs(dz);
                marcar();
            }
            // altura
            float alvoAlt = cHh;
            if (cVert && cVacc && !cVlk) { vAlt += vz * dt; alvoAlt = cHh + vAlt; }
            else vAlt *= (float) Math.exp(-dt * 3);
            float ymax = cHcl > 0 ? cHcl : 99f;
            y = Estado.limitar(alvoAlt, .1f, ymax);
        }
    }
    private float vAlt;

    private static float zona(float v, float db) {
        float m = Math.abs(v) - db;
        return m > 0 ? (v < 0 ? -m : m) : 0;
    }

    // ================= GPS =================
    private void iniciarGps() {
        gpsEstado = "aguardando sinal…";
        lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 23 && ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            gpsEstado = "permissão negada (libere a localização)";
            return;
        }
        if (tipoRot != Sensor.TYPE_ROTATION_VECTOR) { gpsEstado = "sem bússola neste aparelho — GPS precisa dela"; return; }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0, this);
        } catch (SecurityException | IllegalArgumentException ex) { gpsEstado = "erro no GPS"; }
    }

    private void pararGps() {
        if (lm != null) { try { lm.removeUpdates(this); } catch (Exception ignore) {} }
        gpsTem = false;
    }

    @Override
    public void onLocationChanged(Location c) {
        float acc = c.hasAccuracy() ? c.getAccuracy() : 99f;
        if (acc > 30) { gpsEstado = "sinal fraco (" + Math.round(acc) + " m)"; return; }
        gpsEstado = "ok · precisão " + Math.round(acc) + " m";
        if (!gpsTem) { lat0 = c.getLatitude(); lon0 = c.getLongitude(); gpsTem = true; gfx = gfy = gtx = gty = gax = gay = 0; return; }
        float E = (float) ((c.getLongitude() - lon0) * 111320 * Math.cos(Math.toRadians(lat0)));
        float N = (float) ((c.getLatitude() - lat0) * 110540);
        boolean quieto = c.hasSpeed() && c.getSpeed() < .35f;            // parado: o GPS "treme" alguns metros; ignora
        if (!quieto) {
            float k = acc <= 5 ? .6f : acc <= 10 ? .45f : .3f;
            gfx += (E - gfx) * k; gfy += (N - gfy) * k;
            if (Math.hypot(gfx - gtx, gfy - gty) > Math.max(1.5f, acc * .4f)) { gtx = gfx; gty = gfy; }   // zona morta
        }
    }

    private void gpsPasso(float dt) {
        float ex = gtx - gax, ey = gty - gay;
        if (Math.hypot(ex, ey) < 1e-3) return;
        float k = 1 - (float) Math.exp(-dt * 1.5f), dE = ex * k, dN = ey * k;
        gax += dE; gay += dN;
        double o = offAbs;                                               // rumo do app em relação ao norte
        float dir = (float) (dE * Math.sin(o) + dN * Math.cos(o));
        float dlat = (float) (dE * Math.cos(o) - dN * Math.sin(o));
        x += dlat; z -= dir;
        distancia += (float) Math.hypot(dE, dN);
        marcar();
    }

    @Override public void onStatusChanged(String p, int s, Bundle b) {}
    @Override public void onProviderEnabled(String p) {}
    @Override public void onProviderDisabled(String p) { gpsEstado = "GPS desligado no aparelho"; }

    // ================= texto de estado =================
    private static String fmt(float v) { return String.format(new Locale("pt", "BR"), "%.2f", v); }
    private static String g(float rad) { return String.format(new Locale("pt", "BR"), "%.0f°", Math.toDegrees(rad)); }

    public String status() {
        StringBuilder s = new StringBuilder();
        s.append("6DOF simulado: ").append(cOn ? "ligado" : "desligado")
         .append(" · ").append(cGps ? "GPS" : "passos").append('\n');
        s.append("Giro: ").append(fonte).append('\n');
        s.append("Olhar: ").append(g(yaw)).append("  inclinação ").append(g(pitch)).append("  rolagem ").append(g(roll)).append('\n');
        s.append("Posição: x ").append(fmt(x)).append(" · altura ").append(fmt(y)).append(" · z ").append(fmt(z)).append(" m\n");
        s.append("Passos: ").append(passos).append(" · distância ").append(fmt(distancia)).append(" m · passo ").append(fmt(cPlen)).append(" m\n");
        s.append("Aparelho: ").append(parado ? "parado (zona de repouso ativa)" : "em movimento");
        if (cGps) s.append("\nGPS: ").append(gpsEstado);
        if (calOn) s.append("\nCalibrando: ").append(calPassos).append(" passos contados");
        return s.toString();
    }
}
