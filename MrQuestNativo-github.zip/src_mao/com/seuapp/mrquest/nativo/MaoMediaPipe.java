package com.seuapp.mrquest.nativo;

import android.content.Context;
import android.graphics.Bitmap;

import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.core.Delegate;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult;

import java.util.List;

/** Detecção de mão com MediaPipe Hand Landmarker (modo LIVE_STREAM). Modelo: assets/hand_landmarker.task. */
public class MaoMediaPipe implements Mao {
    private Context ctx;
    private Ouvinte ou;
    private volatile HandLandmarker hl;
    private volatile boolean ocupado, gpu;
    private volatile String estado = "iniciando";
    private long envioMs;
    private float lat;

    public MaoMediaPipe() { }

    @Override public void iniciar(Context c, Ouvinte o) {
        ctx = c.getApplicationContext();
        ou = o;
        final boolean tentarGpu = !"CPU".equals(Estado.s("hdel", "AUTO"));
        new Thread(new Runnable() {   // carregar o modelo demora: fora da thread de tela
            @Override public void run() { criar(tentarGpu); }
        }).start();
    }

    private synchronized void criar(boolean comGpu) {
        fechar();
        try {
            int hn = Estado.i("hn", 0), sens = Estado.i("sens", 1);
            float conf = sens == 0 ? .6f : (sens == 1 ? .5f : .35f);
            BaseOptions base = BaseOptions.builder()
                    .setModelAssetPath("hand_landmarker.task")
                    .setDelegate(comGpu ? Delegate.GPU : Delegate.CPU)
                    .build();
            HandLandmarker.HandLandmarkerOptions op = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(base)
                    .setRunningMode(RunningMode.LIVE_STREAM)
                    .setNumHands(hn == 2 ? 2 : 1)
                    .setMinHandDetectionConfidence(conf)
                    .setMinHandPresenceConfidence(conf)
                    .setMinTrackingConfidence(conf)
                    .setResultListener((HandLandmarkerResult r, com.google.mediapipe.framework.image.MPImage in) -> resultado(r))
                    .setErrorListener((RuntimeException e) -> falha(e))
                    .build();
            hl = HandLandmarker.createFromOptions(ctx, op);
            gpu = comGpu;
            estado = "ligada (" + (comGpu ? "GPU" : "CPU") + ")";
        } catch (Throwable t) {
            hl = null;
            if (comGpu) { criar(false); return; }   // GPU não deu: cai para CPU
            estado = "erro: " + t;
        }
    }

    private void resultado(HandLandmarkerResult r) {
        lat += (System.currentTimeMillis() - envioMs - lat) * .2f;
        ocupado = false;
        try {
            List<List<NormalizedLandmark>> ls = r.landmarks();
            if (ls == null || ls.isEmpty()) { ou.resultado(null, null); return; }
            List<NormalizedLandmark> m = ls.get(0);
            float[] xs = new float[m.size()], ys = new float[m.size()];
            for (int i = 0; i < xs.length; i++) { xs[i] = m.get(i).x(); ys[i] = m.get(i).y(); }
            ou.resultado(xs, ys);
        } catch (Throwable t) { estado = "erro no resultado: " + t; }
    }

    private void falha(RuntimeException e) {
        ocupado = false;
        if (gpu) {   // GPU falhou depois de criar: refaz em CPU
            gpu = false;
            estado = "GPU falhou, trocando para CPU";
            new Thread(new Runnable() { @Override public void run() { criar(false); } }).start();
        } else estado = "erro: " + e;
    }

    @Override public boolean livre() { return hl != null && !ocupado; }

    @Override public void enviar(Bitmap b, long ts) {
        HandLandmarker h = hl;
        if (h == null || ocupado) return;
        ocupado = true;
        envioMs = System.currentTimeMillis();
        try { h.detectAsync(new BitmapImageBuilder(b).build(), ts); }
        catch (Throwable t) { ocupado = false; estado = "erro: " + t; }
    }

    private void fechar() {
        HandLandmarker h = hl;
        hl = null;
        ocupado = false;
        if (h != null) try { h.close(); } catch (Throwable t) { }
    }

    @Override public void parar() { fechar(); estado = "desligada"; }

    @Override public String estado() { return estado + (hl != null ? String.format(" · latência %.0f ms", lat) : ""); }
}
