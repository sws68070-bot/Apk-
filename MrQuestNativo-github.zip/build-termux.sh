#!/data/data/com.termux/files/usr/bin/bash
# Compila o MrQuest nativo no Termux, sem Gradle.
# Uso:  bash build.sh            -> gera build/MrQuest-nativo.apk
#       bash build.sh instalar   -> gera e abre o instalador
# A detecção de mão (MediaPipe) é opcional: o script tenta baixar as bibliotecas e o modelo;
# se algo falhar, o app é compilado SEM a mão e todo o resto continua funcionando.
set -e
cd "$(dirname "$0")"

PKG=com.seuapp.mrquest.nativo
OUT=build
APK=$OUT/MrQuest-nativo.apk
KS=$HOME/.mrquest-debug.keystore
AJAR=${ANDROID_JAR:-$HOME/android.jar}
AJAR_URL=https://raw.githubusercontent.com/Sable/android-platforms/master/android-33/android.jar
MP=$HOME/.mrquest-mp                       # cache das bibliotecas do MediaPipe (baixa uma vez só)
M2=https://repo1.maven.org/maven2
MPV=0.10.14
MODELO_URL=https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task

echo "==> 1/8 Conferindo ferramentas"
FALTA=""
for c in aapt2 javac keytool apksigner curl unzip zip; do command -v $c >/dev/null || FALTA="$FALTA $c"; done
if [ -n "$FALTA" ]; then
  echo "    instalando pacotes do Termux..."
  pkg install -y openjdk-17 aapt2 apksigner d8 zipalign curl unzip zip 2>/dev/null || pkg install -y openjdk-17 aapt2 apksigner dx curl unzip zip
fi
command -v d8 >/dev/null || command -v dx >/dev/null || pkg install -y d8 2>/dev/null || pkg install -y dx
command -v zipalign >/dev/null || pkg install -y zipalign 2>/dev/null || true

if [ ! -s "$AJAR" ]; then
  echo "==> Baixando android.jar (uma vez só)"
  curl -L --fail -o "$AJAR" "$AJAR_URL"
fi

# ---------------- MediaPipe (mão) ----------------
echo "==> 2/8 MediaPipe (detecção de mão) — opcional"
mkdir -p $MP/jars $MP/aar $MP/lib/arm64-v8a $MP/lib/armeabi-v7a
get()  { [ -s "$2" ] || curl -sL --fail -m 180 -o "$2" "$1" 2>/dev/null || { rm -f "$2"; return 1; }; }
aar()  { # grupo artefato versao  (baixa o .aar e separa classes.jar + bibliotecas nativas)
  local a=$2 v=$3 d=$MP/aar/$2-$3
  get $M2/$1/$a/$v/$a-$v.aar $MP/aar/$a-$v.aar || return 1
  mkdir -p $d && ( cd $d && unzip -qo ../$a-$v.aar classes.jar 'jni/*' 2>/dev/null || true )
  [ -f $d/classes.jar ] && cp $d/classes.jar $MP/jars/$a-$v.jar
  for abi in arm64-v8a armeabi-v7a; do ls $d/jni/$abi/*.so >/dev/null 2>&1 && cp $d/jni/$abi/*.so $MP/lib/$abi/ || true; done
  return 0; }
jar_() { get $M2/$1/$2/$3/$2-$3.jar $MP/jars/$2-$3.jar; }

MP_OK=0
if aar com/google/mediapipe tasks-vision $MPV && aar com/google/mediapipe tasks-core $MPV; then
  # dependências declaradas no POM que também são do MediaPipe (ex.: tasks-components), se houver
  for a in tasks-vision tasks-core; do
    get $M2/com/google/mediapipe/$a/$MPV/$a-$MPV.pom $MP/$a.pom || true
    [ -s $MP/$a.pom ] && tr -d '\n ' < $MP/$a.pom | sed 's#</dependency>#\n#g' \
      | sed -n 's#.*<groupId>com.google.mediapipe</groupId><artifactId>\([^<]*\)</artifactId><version>\([0-9][^<]*\)</version>.*#\1 \2#p' \
      | while read na nv; do [ -f $MP/jars/$na-$nv.jar ] || aar com/google/mediapipe $na $nv || jar_ com/google/mediapipe $na $nv || true; done
  done
  # dependências comuns (runtime) — falhas aqui não param o build
  jar_ com/google/protobuf protobuf-javalite 3.25.1 || true
  jar_ com/google/guava guava 32.1.3-android || true
  jar_ com/google/guava failureaccess 1.0.2 || true
  jar_ com/google/flogger flogger 0.7.4 || true
  jar_ com/google/flogger flogger-system-backend 0.7.4 || true
  jar_ com/google/code/findbugs jsr305 3.0.2 || true
  get $MODELO_URL $MP/hand_landmarker.task || true
  if [ -s $MP/hand_landmarker.task ] && ls $MP/lib/arm64-v8a/*.so >/dev/null 2>&1; then MP_OK=1; fi
fi
if [ $MP_OK = 1 ]; then echo "    OK: MediaPipe baixado"; else echo "    não deu para baixar o MediaPipe — compilando SEM a detecção de mão"; fi
MPCP=""
[ $MP_OK = 1 ] && MPCP=$(ls $MP/jars/*.jar | tr '\n' ':')

rm -rf $OUT; mkdir -p $OUT/{res,gen,classes,assets}

echo "==> 3/8 Compilando recursos (res/ -> .flat)"
aapt2 compile --dir res -o $OUT/res

echo "==> 4/8 Ligando recursos + manifest (gera R.java)"
ASSETS=""
if [ $MP_OK = 1 ]; then cp $MP/hand_landmarker.task $OUT/assets/; ASSETS="-A $OUT/assets"; fi
aapt2 link -o $OUT/base.apk -I "$AJAR" --manifest AndroidManifest.xml $ASSETS \
  --java $OUT/gen --min-sdk-version 21 --target-sdk-version 33 \
  --auto-add-overlay $OUT/res/*.flat

echo "==> 5/8 Compilando Java"
SRC=$(find src $OUT/gen -name '*.java')
if [ $MP_OK = 1 ]; then
  if ! javac -encoding UTF-8 --release 8 -Xlint:-options -classpath "$AJAR:$MPCP" -d $OUT/classes $SRC $(find src_mao -name '*.java'); then
    echo "    !! o código da mão não compilou com esta versão do MediaPipe — seguindo SEM a mão (me mande o erro acima)"
    MP_OK=0; rm -rf $OUT/classes; mkdir -p $OUT/classes; rm -f $OUT/assets/hand_landmarker.task
  fi
fi
if [ $MP_OK = 0 ]; then
  javac -encoding UTF-8 --release 8 -Xlint:-options -classpath "$AJAR" -d $OUT/classes $SRC
fi

echo "==> 6/8 Gerando classes.dex"
CLS=$(find $OUT/classes -name '*.class')
JARS=""; [ $MP_OK = 1 ] && JARS=$(ls $MP/jars/*.jar)
if command -v d8 >/dev/null; then
  d8 --release --min-api 21 --lib "$AJAR" --output $OUT $CLS $JARS
else
  dx --dex --output=$OUT/classes.dex $OUT/classes
fi

echo "==> 7/8 Montando APK"
cp $OUT/base.apk $OUT/unsigned.apk
( cd $OUT && zip -q -j unsigned.apk classes.dex )
if [ $MP_OK = 1 ]; then
  mkdir -p $OUT/apkx
  for abi in arm64-v8a armeabi-v7a; do
    if ls $MP/lib/$abi/*.so >/dev/null 2>&1; then mkdir -p $OUT/apkx/lib/$abi; cp $MP/lib/$abi/*.so $OUT/apkx/lib/$abi/; fi
  done
  ( cd $OUT/apkx && zip -q -0 -r ../unsigned.apk lib )     # .so sem compressão (zipalign alinha)
fi
if command -v zipalign >/dev/null; then
  zipalign -f -p 4 $OUT/unsigned.apk $OUT/aligned.apk
else
  cp $OUT/unsigned.apk $OUT/aligned.apk
fi

echo "==> 8/8 Assinando"
[ -f "$KS" ] || keytool -genkeypair -keystore "$KS" -alias mrquest -keyalg RSA -keysize 2048 \
  -validity 10000 -storepass mrquest123 -keypass mrquest123 -dname "CN=MrQuest"
apksigner sign --ks "$KS" --ks-key-alias mrquest --ks-pass pass:mrquest123 \
  --key-pass pass:mrquest123 --out $APK $OUT/aligned.apk

echo
if [ $MP_OK = 1 ]; then echo "Pronto (COM detecção de mão): $APK"; else echo "Pronto (sem detecção de mão): $APK"; fi
if [ "$1" = "instalar" ]; then
  termux-open "$APK" 2>/dev/null || echo "Abra o arquivo acima pelo gerenciador de arquivos pra instalar."
else
  echo "Instalar: bash build.sh instalar   (ou abra $APK pelo gerenciador de arquivos)"
fi
