#!/usr/bin/env bash
# Compila o MrQuest nativo no GitHub Actions (Ubuntu). Sem Gradle.
set -euo pipefail
cd "$(dirname "$0")"
SDK=${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}
BT=$(ls -d "$SDK"/build-tools/* | sort -V | tail -1)
AJAR=$(ls -d "$SDK"/platforms/android-3[3-9]/android.jar 2>/dev/null | sort -V | tail -1)
[ -f "$AJAR" ] || AJAR=$(ls "$SDK"/platforms/*/android.jar | sort -V | tail -1)
echo "build-tools: $BT"; echo "android.jar: $AJAR"
OUT=build; APK=$OUT/MrQuest-nativo.apk
KS=${KEYSTORE:-$OUT/debug.keystore}
rm -rf $OUT; mkdir -p $OUT/{res,gen,classes}

"$BT/aapt2" compile --dir res -o $OUT/res
"$BT/aapt2" link -o $OUT/base.apk -I "$AJAR" --manifest AndroidManifest.xml \
  --java $OUT/gen --min-sdk-version 21 --target-sdk-version 33 \
  --auto-add-overlay $OUT/res/*.flat

# Parte 1: compila SEM a mão (MediaPipe entra numa parte futura)
javac -encoding UTF-8 --release 8 -Xlint:-options -classpath "$AJAR" \
  -d $OUT/classes $(find src $OUT/gen -name '*.java')

"$BT/d8" --release --min-api 21 --lib "$AJAR" --output $OUT $(find $OUT/classes -name '*.class')
cp $OUT/base.apk $OUT/unsigned.apk
( cd $OUT && zip -q -j unsigned.apk classes.dex )
"$BT/zipalign" -f -p 4 $OUT/unsigned.apk $OUT/aligned.apk

[ -f "$KS" ] || keytool -genkeypair -keystore "$KS" -alias mrquest -keyalg RSA -keysize 2048 \
  -validity 10000 -storepass mrquest123 -keypass mrquest123 -dname "CN=MrQuest"
"$BT/apksigner" sign --ks "$KS" --ks-key-alias mrquest --ks-pass pass:mrquest123 \
  --key-pass pass:mrquest123 --out $APK $OUT/aligned.apk
ls -la $APK
